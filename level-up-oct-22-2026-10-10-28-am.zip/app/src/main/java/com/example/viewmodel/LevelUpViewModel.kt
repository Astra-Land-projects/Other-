package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.GeminiCoachService
import com.example.data.model.Achievement
import com.example.data.model.ActivityLog
import com.example.data.model.GamificationEngine
import com.example.data.model.Goal
import com.example.data.model.Habit
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.example.data.repository.LevelUpRepository
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class LevelUpEvent {
  data class LevelUpCelebration(val newLevel: Int, val title: String) : LevelUpEvent()
  data class AchievementUnlocked(val achievement: Achievement) : LevelUpEvent()
  data class Message(val text: String) : LevelUpEvent()
}

class LevelUpViewModel(application: Application) : AndroidViewModel(application) {

  private val repository = LevelUpRepository(application)
  private val auth: FirebaseAuth = FirebaseAuth.getInstance()

  private val _userProfile = MutableStateFlow<UserProfile?>(null)
  val userProfile: StateFlow<UserProfile?> = _userProfile.asStateFlow()

  private val _habits = MutableStateFlow<List<Habit>>(emptyList())
  val habits: StateFlow<List<Habit>> = _habits.asStateFlow()

  private val _tasks = MutableStateFlow<List<TaskItem>>(emptyList())
  val tasksState: StateFlow<List<TaskItem>> = _tasks.asStateFlow()

  private val _goals = MutableStateFlow<List<Goal>>(emptyList())
  val goals: StateFlow<List<Goal>> = _goals.asStateFlow()

  private val _activityLogs = MutableStateFlow<List<ActivityLog>>(emptyList())
  val activityLogs: StateFlow<List<ActivityLog>> = _activityLogs.asStateFlow()

  private val _achievements = MutableStateFlow<List<Achievement>>(emptyList())
  val achievements: StateFlow<List<Achievement>> = _achievements.asStateFlow()

  private val _events = MutableSharedFlow<LevelUpEvent>()
  val events: SharedFlow<LevelUpEvent> = _events.asSharedFlow()

  private val _aiCoachMessage = MutableStateFlow<String?>(null)
  val aiCoachMessage: StateFlow<String?> = _aiCoachMessage.asStateFlow()

  private val _isAiLoading = MutableStateFlow(false)
  val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

  // Selected filters
  val selectedHabitCategory = MutableStateFlow("All")
  val selectedTaskFilter = MutableStateFlow("All") // "All", "Pending", "Completed", "High Priority"
  val selectedGoalTimeframe = MutableStateFlow("All")

  init {
    val currentUser = auth.currentUser
    if (currentUser != null) {
      observeAllData()
    }
  }

  fun onUserAuthenticated() {
    viewModelScope.launch {
      val user = auth.currentUser ?: return@launch
      repository.initializeUserIfNew(user)
      observeAllData()
    }
  }

  private fun observeAllData() {
    viewModelScope.launch {
      repository.observeUserProfile().collectLatest { profile ->
        _userProfile.value = profile
      }
    }
    viewModelScope.launch {
      repository.observeHabits().collectLatest { habitList ->
        _habits.value = habitList
      }
    }
    viewModelScope.launch {
      repository.observeTasks().collectLatest { taskList ->
        _tasks.value = taskList
      }
    }
    viewModelScope.launch {
      repository.observeGoals().collectLatest { goalList ->
        _goals.value = goalList
      }
    }
    viewModelScope.launch {
      repository.observeActivityLogs().collectLatest { logList ->
        _activityLogs.value = logList
      }
    }
    viewModelScope.launch {
      repository.observeAchievements().collectLatest { achList ->
        _achievements.value = achList
      }
    }
  }

  // --- HABIT OPERATIONS ---

  fun toggleHabitCompletion(habit: Habit) {
    viewModelScope.launch {
      val today = GamificationEngine.getTodayDateString()
      val isAlreadyCompletedToday = habit.isCompletedOn(today)

      if (isAlreadyCompletedToday) {
        // Uncomplete (remove today) without awarding XP again
        val updatedDates = habit.completionDates.filter { it != today }
        val newStreak = GamificationEngine.calculateStreak(updatedDates)
        val updatedHabit = habit.copy(
          completionDates = updatedDates,
          currentStreak = newStreak
        )
        repository.updateHabit(updatedHabit)
        _events.emit(LevelUpEvent.Message("Habit marked uncompleted"))
      } else {
        // Complete habit for today and earn XP
        val updatedDates = (habit.completionDates + today).distinct()
        val newStreak = GamificationEngine.calculateStreak(updatedDates)
        val bestStreak = maxOf(habit.bestStreak, newStreak)
        val updatedHabit = habit.copy(
          completionDates = updatedDates,
          currentStreak = newStreak,
          bestStreak = bestStreak
        )
        repository.updateHabit(updatedHabit)

        // Award XP
        awardXp(habit.xpReward, "Habit: ${habit.name}")

        // Log activity
        repository.addActivityLog(
          ActivityLog(
            title = "Completed habit: ${habit.name}",
            type = "habit",
            xpEarned = habit.xpReward,
            date = today
          )
        )

        // Increment habits count & evaluate achievements
        val currentProfile = _userProfile.value
        if (currentProfile != null) {
          val newHabitsCount = currentProfile.completedHabitsCount + 1
          val allDates = _habits.value.flatMap { it.completionDates } + today
          val userGlobalStreak = GamificationEngine.calculateStreak(allDates)
          val bestGlobalStreak = maxOf(currentProfile.bestStreak, userGlobalStreak)

          repository.updateUserProfile(
            currentProfile.copy(
              completedHabitsCount = newHabitsCount,
              currentStreak = userGlobalStreak,
              bestStreak = bestGlobalStreak,
              lastActiveDate = today
            )
          )
          checkAchievements(
            completedHabitsCount = newHabitsCount,
            streak = userGlobalStreak,
            category = habit.category
          )
        }
      }
    }
  }

  fun saveHabit(
    id: String = "",
    name: String,
    description: String,
    category: String,
    xpReward: Int,
    target: String,
    frequency: String
  ) {
    viewModelScope.launch {
      if (id.isBlank()) {
        val newHabit = Habit(
          name = name.trim(),
          description = description.trim().ifBlank { null },
          category = category,
          xpReward = xpReward,
          targetDurationOrQuantity = target.trim().ifBlank { null },
          frequency = frequency
        )
        repository.createHabit(newHabit)
        _events.emit(LevelUpEvent.Message("New habit created (+0 XP, complete to level up!)"))
      } else {
        val existing = _habits.value.find { it.id == id } ?: return@launch
        val updated = existing.copy(
          name = name.trim(),
          description = description.trim().ifBlank { null },
          category = category,
          xpReward = xpReward,
          targetDurationOrQuantity = target.trim().ifBlank { null },
          frequency = frequency
        )
        repository.updateHabit(updated)
        _events.emit(LevelUpEvent.Message("Habit updated"))
      }
    }
  }

  fun deleteHabit(habitId: String) {
    viewModelScope.launch {
      repository.deleteHabit(habitId)
      _events.emit(LevelUpEvent.Message("Habit deleted"))
    }
  }

  // --- TASK OPERATIONS ---

  fun toggleTaskCompletion(task: TaskItem) {
    viewModelScope.launch {
      val today = GamificationEngine.getTodayDateString()
      val willBeCompleted = !task.isCompleted
      val updatedTask = task.copy(isCompleted = willBeCompleted)
      repository.updateTask(updatedTask)

      if (willBeCompleted) {
        awardXp(task.xpReward, "Task: ${task.title}")
        repository.addActivityLog(
          ActivityLog(
            title = "Completed task: ${task.title}",
            type = "task",
            xpEarned = task.xpReward,
            date = today
          )
        )
        val profile = _userProfile.value
        if (profile != null) {
          val newCount = profile.completedTasksCount + 1
          repository.updateUserProfile(profile.copy(completedTasksCount = newCount))
          checkAchievements(completedTasksCount = newCount, category = task.category)
        }
      } else {
        _events.emit(LevelUpEvent.Message("Task reopened"))
      }
    }
  }

  fun saveTask(
    id: String = "",
    title: String,
    description: String,
    category: String,
    priority: String,
    dueDate: String,
    xpReward: Int
  ) {
    viewModelScope.launch {
      if (id.isBlank()) {
        val newTask = TaskItem(
          title = title.trim(),
          description = description.trim().ifBlank { null },
          category = category,
          priority = priority,
          dueDate = dueDate.trim().ifBlank { null },
          xpReward = xpReward
        )
        repository.createTask(newTask)
        _events.emit(LevelUpEvent.Message("Task created"))
      } else {
        val existing = _tasks.value.find { it.id == id } ?: return@launch
        val updated = existing.copy(
          title = title.trim(),
          description = description.trim().ifBlank { null },
          category = category,
          priority = priority,
          dueDate = dueDate.trim().ifBlank { null },
          xpReward = xpReward
        )
        repository.updateTask(updated)
        _events.emit(LevelUpEvent.Message("Task updated"))
      }
    }
  }

  fun deleteTask(taskId: String) {
    viewModelScope.launch {
      repository.deleteTask(taskId)
      _events.emit(LevelUpEvent.Message("Task deleted"))
    }
  }

  // --- GOAL OPERATIONS ---

  fun updateGoalProgress(goal: Goal, newCurrent: Int) {
    viewModelScope.launch {
      val target = goal.targetValue.coerceAtLeast(1)
      val clamped = newCurrent.coerceIn(0, target)
      val isNowCompleted = clamped >= target
      val wasCompleted = goal.isCompleted

      val updated = goal.copy(
        currentValue = clamped,
        isCompleted = isNowCompleted
      )
      repository.updateGoal(updated)

      if (isNowCompleted && !wasCompleted) {
        awardXp(goal.xpReward, "Major Goal: ${goal.title}")
        repository.addActivityLog(
          ActivityLog(
            title = "Achieved Goal: ${goal.title}",
            type = "goal",
            xpEarned = goal.xpReward,
            date = GamificationEngine.getTodayDateString()
          )
        )
        checkAchievements(goalAchieved = true, category = goal.category)
        _events.emit(LevelUpEvent.Message("🏆 GOAL ACHIEVED! +${goal.xpReward} XP"))
      }
    }
  }

  fun saveGoal(
    id: String = "",
    title: String,
    description: String,
    category: String,
    timeframe: String,
    targetValue: Int,
    unit: String,
    deadline: String,
    xpReward: Int
  ) {
    viewModelScope.launch {
      if (id.isBlank()) {
        val newGoal = Goal(
          title = title.trim(),
          description = description.trim().ifBlank { null },
          category = category,
          timeframe = timeframe,
          targetValue = targetValue.coerceAtLeast(1),
          currentValue = 0,
          unit = unit.trim().ifBlank { "units" },
          deadline = deadline.trim().ifBlank { null },
          xpReward = xpReward
        )
        repository.createGoal(newGoal)
        _events.emit(LevelUpEvent.Message("Goal locked in! Ascend to victory."))
      } else {
        val existing = _goals.value.find { it.id == id } ?: return@launch
        val updated = existing.copy(
          title = title.trim(),
          description = description.trim().ifBlank { null },
          category = category,
          timeframe = timeframe,
          targetValue = targetValue.coerceAtLeast(1),
          unit = unit.trim().ifBlank { "units" },
          deadline = deadline.trim().ifBlank { null },
          xpReward = xpReward
        )
        repository.updateGoal(updated)
        _events.emit(LevelUpEvent.Message("Goal updated"))
      }
    }
  }

  fun deleteGoal(goalId: String) {
    viewModelScope.launch {
      repository.deleteGoal(goalId)
      _events.emit(LevelUpEvent.Message("Goal deleted"))
    }
  }

  // --- REWARD & LEVEL ENGINE ---

  private suspend fun awardXp(xpPoints: Int, reason: String) {
    val current = _userProfile.value ?: return
    val oldLevel = current.level
    val (newLevel, newCurrentXp, newTotalXp) = GamificationEngine.calculateLevelProgression(
      current.level,
      current.currentXp,
      current.totalXp,
      xpPoints
    )

    val updatedProfile = current.copy(
      level = newLevel,
      currentXp = newCurrentXp,
      totalXp = newTotalXp
    )
    repository.updateUserProfile(updatedProfile)
    _userProfile.value = updatedProfile

    if (newLevel > oldLevel) {
      val title = GamificationEngine.getLevelTitle(newLevel)
      _events.emit(LevelUpEvent.LevelUpCelebration(newLevel, title))
      repository.addActivityLog(
        ActivityLog(
          title = "✨ LEVEL UP! Ascended to Level $newLevel: $title",
          type = "level",
          xpEarned = 0,
          date = GamificationEngine.getTodayDateString()
        )
      )
    } else {
      _events.emit(LevelUpEvent.Message("+$xpPoints XP ($reason)"))
    }
  }

  private suspend fun checkAchievements(
    completedHabitsCount: Int = _userProfile.value?.completedHabitsCount ?: 0,
    completedTasksCount: Int = _userProfile.value?.completedTasksCount ?: 0,
    streak: Int = _userProfile.value?.currentStreak ?: 0,
    goalAchieved: Boolean = false,
    category: String = ""
  ) {
    val currentList = _achievements.value
    val playerLevel = _userProfile.value?.level ?: 1

    currentList.forEach { ach ->
      if (ach.unlocked) return@forEach

      var newProgress = ach.progress
      var shouldUnlock = false

      when (ach.badgeKey) {
        "first_step" -> {
          if (completedHabitsCount > 0 || completedTasksCount > 0) {
            newProgress = 1
            shouldUnlock = true
          }
        }
        "momentum_3" -> {
          newProgress = streak.coerceAtMost(3)
          if (streak >= 3) shouldUnlock = true
        }
        "seven_day_warrior" -> {
          newProgress = streak.coerceAtMost(7)
          if (streak >= 7) shouldUnlock = true
        }
        "task_hunter_5" -> {
          newProgress = completedTasksCount.coerceAtMost(5)
          if (completedTasksCount >= 5) shouldUnlock = true
        }
        "knowledge_seeker" -> {
          if (category.equals("Study", ignoreCase = true) || category.equals("Reading", ignoreCase = true)) {
            newProgress = (ach.progress + 1).coerceAtMost(5)
            if (newProgress >= 5) shouldUnlock = true
          }
        }
        "developer_mode" -> {
          if (category.equals("Programming", ignoreCase = true)) {
            newProgress = 1
            shouldUnlock = true
          }
        }
        "iron_will" -> {
          if (category.equals("Fitness", ignoreCase = true)) {
            newProgress = (ach.progress + 1).coerceAtMost(5)
            if (newProgress >= 5) shouldUnlock = true
          }
        }
        "level_five" -> {
          newProgress = playerLevel.coerceAtMost(5)
          if (playerLevel >= 5) shouldUnlock = true
        }
        "consistency_master" -> {
          newProgress = completedHabitsCount.coerceAtMost(30)
          if (completedHabitsCount >= 30) shouldUnlock = true
        }
      }

      if (newProgress != ach.progress || shouldUnlock) {
        val updatedAch = ach.copy(
          progress = newProgress,
          unlocked = shouldUnlock
        )
        repository.updateAchievement(updatedAch)
        if (shouldUnlock) {
          awardXp(ach.xpReward, "Achievement: ${ach.title}")
          _events.emit(LevelUpEvent.AchievementUnlocked(updatedAch))
          repository.addActivityLog(
            ActivityLog(
              title = "🏅 Unlocked Achievement: ${ach.title}",
              type = "achievement",
              xpEarned = ach.xpReward,
              date = GamificationEngine.getTodayDateString()
            )
          )
        }
      }
    }
  }

  // --- GEMINI AI ASSISTANT ---

  fun generateAiDailyQuest() {
    viewModelScope.launch {
      _isAiLoading.value = true
      val insight = GeminiCoachService.generateDailyMission(_habits.value)
      _aiCoachMessage.value = insight
      _isAiLoading.value = false
    }
  }

  fun breakdownGoalWithAi(goalTitle: String, category: String) {
    viewModelScope.launch {
      _isAiLoading.value = true
      val breakdown = GeminiCoachService.breakdownGoal(goalTitle, category)
      _aiCoachMessage.value = breakdown
      _isAiLoading.value = false
    }
  }

  fun askAiCoach(prompt: String) {
    viewModelScope.launch {
      _isAiLoading.value = true
      val response = GeminiCoachService.askCoach(prompt)
      _aiCoachMessage.value = response
      _isAiLoading.value = false
    }
  }

  fun clearAiMessage() {
    _aiCoachMessage.value = null
  }
}
