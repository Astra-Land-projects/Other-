package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Goal(
  val id: String = "",
  val userId: String = "",
  val title: String = "",
  val description: String? = null,
  val category: String = "Personal",
  val timeframe: String = "Monthly",
  val targetValue: Int = 10,
  val currentValue: Int = 0,
  val unit: String = "units",
  val xpReward: Int = 100,
  val deadline: String? = null,
  @get:PropertyName("isCompleted") @set:PropertyName("isCompleted") var isCompleted: Boolean = false,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
) {
  @get:Exclude
  val progressFraction: Float
    get() = if (targetValue > 0) (currentValue.toFloat() / targetValue.toFloat()).coerceIn(0f, 1f) else 0f

  fun toMap(): Map<String, Any?> = mapOf(
    "id" to id,
    "userId" to userId,
    "title" to title,
    "description" to description,
    "category" to category,
    "timeframe" to timeframe,
    "targetValue" to targetValue,
    "currentValue" to currentValue,
    "unit" to unit,
    "xpReward" to xpReward,
    "deadline" to deadline,
    "isCompleted" to isCompleted
  ).filterValues { it != null }
}
