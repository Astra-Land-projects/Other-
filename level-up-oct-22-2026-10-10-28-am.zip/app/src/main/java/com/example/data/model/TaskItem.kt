package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class TaskItem(
  val id: String = "",
  val userId: String = "",
  val title: String = "",
  val description: String? = null,
  val category: String = "Productivity",
  val priority: String = "Medium",
  val xpReward: Int = 30,
  val dueDate: String? = null,
  @get:PropertyName("isCompleted") @set:PropertyName("isCompleted") var isCompleted: Boolean = false,
  @ServerTimestamp val completedAt: Timestamp? = null,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
) {
  fun toMap(): Map<String, Any?> = mapOf(
    "id" to id,
    "userId" to userId,
    "title" to title,
    "description" to description,
    "category" to category,
    "priority" to priority,
    "xpReward" to xpReward,
    "dueDate" to dueDate,
    "isCompleted" to isCompleted,
    "completedAt" to completedAt
  ).filterValues { it != null }
}
