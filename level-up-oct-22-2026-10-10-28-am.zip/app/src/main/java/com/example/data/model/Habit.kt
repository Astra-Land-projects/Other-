package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Habit(
  val id: String = "",
  val userId: String = "",
  val name: String = "",
  val description: String? = null,
  val category: String = "Study",
  val iconName: String = "menu_book",
  val xpReward: Int = 25,
  val targetDurationOrQuantity: String? = null,
  val frequency: String = "Daily",
  val completionDates: List<String> = emptyList(),
  val currentStreak: Int = 0,
  val bestStreak: Int = 0,
  val archived: Boolean = false,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
) {
  fun isCompletedOn(dateStr: String): Boolean = completionDates.contains(dateStr)

  fun toMap(): Map<String, Any?> = mapOf(
    "id" to id,
    "userId" to userId,
    "name" to name,
    "description" to description,
    "category" to category,
    "iconName" to iconName,
    "xpReward" to xpReward,
    "targetDurationOrQuantity" to targetDurationOrQuantity,
    "frequency" to frequency,
    "completionDates" to completionDates,
    "currentStreak" to currentStreak,
    "bestStreak" to bestStreak,
    "archived" to archived
  ).filterValues { it != null }
}
