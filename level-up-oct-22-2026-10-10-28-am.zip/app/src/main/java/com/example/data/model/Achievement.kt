package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Achievement(
  val id: String = "",
  val userId: String = "",
  val badgeKey: String = "",
  val title: String = "",
  val description: String = "",
  val category: String? = "General",
  val xpReward: Int = 100,
  val unlocked: Boolean = false,
  @ServerTimestamp val unlockedAt: Timestamp? = null,
  val progress: Int = 0,
  val maxProgress: Int = 1,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
) {
  @get:Exclude
  val progressFraction: Float
    get() = if (maxProgress > 0) (progress.toFloat() / maxProgress.toFloat()).coerceIn(0f, 1f) else 0f

  fun toMap(): Map<String, Any?> = mapOf(
    "id" to id,
    "userId" to userId,
    "badgeKey" to badgeKey,
    "title" to title,
    "description" to description,
    "category" to category,
    "xpReward" to xpReward,
    "unlocked" to unlocked,
    "unlockedAt" to unlockedAt,
    "progress" to progress,
    "maxProgress" to maxProgress
  ).filterValues { it != null }
}
