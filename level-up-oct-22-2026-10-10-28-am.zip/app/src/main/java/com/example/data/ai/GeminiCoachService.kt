package com.example.data.ai

import com.example.BuildConfig
import com.example.data.model.Habit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiCoachService {

  private const val MODEL_NAME = "gemini-3.8-flash"
  private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

  private val client: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .connectTimeout(60, TimeUnit.SECONDS)
      .readTimeout(60, TimeUnit.SECONDS)
      .writeTimeout(60, TimeUnit.SECONDS)
      .build()
  }

  suspend fun askCoach(prompt: String): String = withContext(Dispatchers.IO) {
    val apiKey = BuildConfig.GEMINI_API_KEY
    if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
      return@withContext getOfflineCoachInsight(prompt)
    }

    try {
      val payload = JSONObject().apply {
        val contentsArray = JSONArray().apply {
          put(JSONObject().apply {
            put("parts", JSONArray().apply {
              put(JSONObject().apply {
                put("text", "You are the LEVEL UP RPG Questmaster & Habit Coach. Provide concise, high-impact, tactical, and motivating advice. Use subtle RPG terminology (XP, quests, fortitude, leveling up). Keep responses under 120 words.\n\nUser request: $prompt")
              })
            })
          })
        }
        put("contents", contentsArray)
      }

      val requestBody = payload.toString().toRequestBody("application/json".toMediaType())
      val request = Request.Builder()
        .url("$BASE_URL?key=$apiKey")
        .post(requestBody)
        .build()

      val response = client.newCall(request).execute()
      val responseString = response.body?.string() ?: ""

      if (response.isSuccessful) {
        val json = JSONObject(responseString)
        val text = json.optJSONArray("candidates")
          ?.optJSONObject(0)
          ?.optJSONObject("content")
          ?.optJSONArray("parts")
          ?.optJSONObject(0)
          ?.optString("text")

        if (!text.isNullOrBlank()) {
          return@withContext text.trim()
        }
      }
      return@withContext getOfflineCoachInsight(prompt)
    } catch (e: Exception) {
      return@withContext getOfflineCoachInsight(prompt)
    }
  }

  suspend fun breakdownGoal(goalTitle: String, category: String): String {
    val prompt = "Break down this ambitious goal into 3 concrete weekly milestones and 2 daily habits: '$goalTitle' (Category: $category)."
    return askCoach(prompt)
  }

  suspend fun generateDailyMission(habits: List<Habit>): String {
    val habitNames = habits.take(4).joinToString(", ") { it.name }
    val prompt = "Given my current habits ($habitNames), generate a high-focus 'Special Daily Quest' for today to boost momentum and earn bonus XP."
    return askCoach(prompt)
  }

  private fun getOfflineCoachInsight(prompt: String): String {
    return when {
      prompt.contains("break down", ignoreCase = true) || prompt.contains("goal", ignoreCase = true) ->
        "⚡ Quest Plan:\n1. Week 1: Establish foundational baseline (20 mins daily focus).\n2. Week 2: Double volume and eliminate distractions.\n3. Week 3: Execute full practice milestone.\nBonus Habit: Log daily reflection at sunset for +50 XP!"

      prompt.contains("quest", ignoreCase = true) || prompt.contains("mission", ignoreCase = true) ->
        "🗡️ Daily Boss Quest: Complete all morning habits before noon without checking social media. Reward: +75 Bonus XP and a 1-day streak shield!"

      else ->
        "⚔️ 'Every master was once a beginner who refused to quit.' Focus on completing your highest priority task today. Consistency compounds into greatness. Keep climbing!"
    }
  }
}
