package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.Achievement
import com.example.data.model.ActivityLog
import com.example.data.model.GamificationEngine
import com.example.data.model.Goal
import com.example.data.model.Habit
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class LevelUpRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      FirebaseApp.getInstance(),
      context.applicationContext.getString(R.string.firestore_database_id)
    ),
    FirebaseAuth.getInstance()
  )

  private fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
  }

  fun observeUserProfile(): Flow<UserProfile?> = flow {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid)
    val stream = docRef.snapshots()
      .map { snapshot -> snapshot.toObject(UserProfile::class.java) }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.GET, docRef.path)
        throw e
      }
    emitAll(stream)
  }

  fun observeHabits(): Flow<List<Habit>> = flow {
    val uid = requireUserId()
    val colRef = db.collection("users").document(uid).collection("habits")
    val stream = colRef.snapshots()
      .map { snapshot -> snapshot.toObjects(Habit::class.java) }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, colRef.path)
        throw e
      }
    emitAll(stream)
  }

  fun observeTasks(): Flow<List<TaskItem>> = flow {
    val uid = requireUserId()
    val colRef = db.collection("users").document(uid).collection("tasks")
    val stream = colRef.snapshots()
      .map { snapshot -> snapshot.toObjects(TaskItem::class.java) }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, colRef.path)
        throw e
      }
    emitAll(stream)
  }

  fun observeGoals(): Flow<List<Goal>> = flow {
    val uid = requireUserId()
    val colRef = db.collection("users").document(uid).collection("goals")
    val stream = colRef.snapshots()
      .map { snapshot -> snapshot.toObjects(Goal::class.java) }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, colRef.path)
        throw e
      }
    emitAll(stream)
  }

  fun observeActivityLogs(): Flow<List<ActivityLog>> = flow {
    val uid = requireUserId()
    val colRef = db.collection("users").document(uid).collection("activity_logs")
    val stream = colRef.snapshots()
      .map { snapshot ->
        snapshot.toObjects(ActivityLog::class.java)
          .sortedByDescending { it.createdAt?.seconds ?: 0L }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, colRef.path)
        throw e
      }
    emitAll(stream)
  }

  fun observeAchievements(): Flow<List<Achievement>> = flow {
    val uid = requireUserId()
    val colRef = db.collection("users").document(uid).collection("achievements")
    val stream = colRef.snapshots()
      .map { snapshot -> snapshot.toObjects(Achievement::class.java) }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, colRef.path)
        throw e
      }
    emitAll(stream)
  }

  suspend fun initializeUserIfNew(user: FirebaseUser): Result<Unit> = runCatching {
    val uid = user.uid
    val docRef = db.collection("users").document(uid)
    val doc = docRef.get().await()
    if (!doc.exists()) {
      val profile = UserProfile(
        userId = uid,
        displayName = user.displayName ?: "Adventurer",
        email = user.email,
        photoUrl = user.photoUrl?.toString(),
        level = 1,
        currentXp = 0,
        totalXp = 0,
        currentStreak = 0,
        bestStreak = 0,
        lastActiveDate = GamificationEngine.getTodayDateString(),
        completedHabitsCount = 0,
        completedTasksCount = 0
      )
      val payload = profile.toMap() + mapOf(
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
      )
      docRef.set(payload).await()

      // Seed initial sample achievements
      val batch = db.batch()
      val achievements = GamificationEngine.getDefaultAchievements(uid)
      achievements.forEach { achievement ->
        val achRef = db.collection("users").document(uid).collection("achievements").document(achievement.id)
        batch.set(
          achRef,
          achievement.toMap() + mapOf(
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
          )
        )
      }

      // Seed starter habits
      val starterHabits = GamificationEngine.getInitialSampleHabits(uid)
      starterHabits.forEach { habit ->
        val hRef = db.collection("users").document(uid).collection("habits").document(habit.id)
        batch.set(
          hRef,
          habit.toMap() + mapOf(
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
          )
        )
      }

      // Seed starter tasks
      val starterTasks = GamificationEngine.getInitialSampleTasks(uid)
      starterTasks.forEach { task ->
        val tRef = db.collection("users").document(uid).collection("tasks").document(task.id)
        batch.set(
          tRef,
          task.toMap() + mapOf(
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
          )
        )
      }

      // Seed starter goals
      val starterGoals = GamificationEngine.getInitialSampleGoals(uid)
      starterGoals.forEach { goal ->
        val gRef = db.collection("users").document(uid).collection("goals").document(goal.id)
        batch.set(
          gRef,
          goal.toMap() + mapOf(
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
          )
        )
      }

      batch.commit().await()
    }
  }

  suspend fun updateUserProfile(profile: UserProfile): Result<Unit> = runCatching {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid)
    val existing = docRef.get().await()
    val createdAt = existing.getTimestamp("createdAt") ?: FieldValue.serverTimestamp()
    val payload = profile.toMap() + mapOf(
      "createdAt" to createdAt,
      "updatedAt" to FieldValue.serverTimestamp()
    )
    docRef.set(payload).await()
  }

  suspend fun createHabit(habit: Habit): Result<String> = runCatching {
    val uid = requireUserId()
    val habitId = if (habit.id.isNotBlank()) habit.id else "habit_${UUID.randomUUID()}"
    val docRef = db.collection("users").document(uid).collection("habits").document(habitId)
    val finalHabit = habit.copy(id = habitId, userId = uid)
    val payload = finalHabit.toMap() + mapOf(
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp()
    )
    docRef.set(payload).await()
    habitId
  }

  suspend fun updateHabit(habit: Habit): Result<Unit> = runCatching {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("habits").document(habit.id)
    val existing = docRef.get().await()
    val createdAt = existing.getTimestamp("createdAt") ?: FieldValue.serverTimestamp()
    val payload = habit.toMap() + mapOf(
      "createdAt" to createdAt,
      "updatedAt" to FieldValue.serverTimestamp()
    )
    docRef.set(payload).await()
  }

  suspend fun deleteHabit(habitId: String): Result<Unit> = runCatching {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("habits").document(habitId)
    docRef.delete().await()
  }

  suspend fun createTask(task: TaskItem): Result<String> = runCatching {
    val uid = requireUserId()
    val taskId = if (task.id.isNotBlank()) task.id else "task_${UUID.randomUUID()}"
    val docRef = db.collection("users").document(uid).collection("tasks").document(taskId)
    val finalTask = task.copy(id = taskId, userId = uid)
    val payload = finalTask.toMap() + mapOf(
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp()
    )
    docRef.set(payload).await()
    taskId
  }

  suspend fun updateTask(task: TaskItem): Result<Unit> = runCatching {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("tasks").document(task.id)
    val existing = docRef.get().await()
    val createdAt = existing.getTimestamp("createdAt") ?: FieldValue.serverTimestamp()
    val payload = task.toMap() + mapOf(
      "createdAt" to createdAt,
      "updatedAt" to FieldValue.serverTimestamp()
    )
    docRef.set(payload).await()
  }

  suspend fun deleteTask(taskId: String): Result<Unit> = runCatching {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("tasks").document(taskId)
    docRef.delete().await()
  }

  suspend fun createGoal(goal: Goal): Result<String> = runCatching {
    val uid = requireUserId()
    val goalId = if (goal.id.isNotBlank()) goal.id else "goal_${UUID.randomUUID()}"
    val docRef = db.collection("users").document(uid).collection("goals").document(goalId)
    val finalGoal = goal.copy(id = goalId, userId = uid)
    val payload = finalGoal.toMap() + mapOf(
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp()
    )
    docRef.set(payload).await()
    goalId
  }

  suspend fun updateGoal(goal: Goal): Result<Unit> = runCatching {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("goals").document(goal.id)
    val existing = docRef.get().await()
    val createdAt = existing.getTimestamp("createdAt") ?: FieldValue.serverTimestamp()
    val payload = goal.toMap() + mapOf(
      "createdAt" to createdAt,
      "updatedAt" to FieldValue.serverTimestamp()
    )
    docRef.set(payload).await()
  }

  suspend fun deleteGoal(goalId: String): Result<Unit> = runCatching {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("goals").document(goalId)
    docRef.delete().await()
  }

  suspend fun addActivityLog(log: ActivityLog): Result<String> = runCatching {
    val uid = requireUserId()
    val logId = if (log.id.isNotBlank()) log.id else "log_${UUID.randomUUID()}"
    val docRef = db.collection("users").document(uid).collection("activity_logs").document(logId)
    val finalLog = log.copy(id = logId, userId = uid)
    val payload = finalLog.toMap() + mapOf(
      "createdAt" to FieldValue.serverTimestamp()
    )
    docRef.set(payload).await()
    logId
  }

  suspend fun updateAchievement(achievement: Achievement): Result<Unit> = runCatching {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("achievements").document(achievement.id)
    val existing = docRef.get().await()
    val createdAt = existing.getTimestamp("createdAt") ?: FieldValue.serverTimestamp()
    val payload = achievement.toMap() + mapOf(
      "createdAt" to createdAt,
      "updatedAt" to FieldValue.serverTimestamp()
    )
    docRef.set(payload).await()
  }

  suspend fun getUserProfileOnce(): UserProfile? {
    val uid = requireUserId()
    val doc = db.collection("users").document(uid).get().await()
    return doc.toObject(UserProfile::class.java)
  }

  suspend fun getHabitsOnce(): List<Habit> {
    val uid = requireUserId()
    val snap = db.collection("users").document(uid).collection("habits").get().await()
    return snap.toObjects(Habit::class.java)
  }

  suspend fun getTasksOnce(): List<TaskItem> {
    val uid = requireUserId()
    val snap = db.collection("users").document(uid).collection("tasks").get().await()
    return snap.toObjects(TaskItem::class.java)
  }
}
