package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
  val id: String = "",
  val userId: String = "",
  val displayName: String = "Player",
  val email: String? = null,
  val photoUrl: String? = null,
  val level: Int = 1,
  val currentXp: Int = 0,
  val totalXp: Int = 0,
  val currentStreak: Int = 0,
  val bestStreak: Int = 0,
  val lastActiveDate: String? = null,
  val completedHabitsCount: Int = 0,
  val completedTasksCount: Int = 0,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
) {
  fun toMap(): Map<String, Any?> = mapOf(
    "userId" to userId,
    "displayName" to displayName,
    "email" to email,
    "photoUrl" to photoUrl,
    "level" to level,
    "currentXp" to currentXp,
    "totalXp" to totalXp,
    "currentStreak" to currentStreak,
    "bestStreak" to bestStreak,
    "lastActiveDate" to lastActiveDate,
    "completedHabitsCount" to completedHabitsCount,
    "completedTasksCount" to completedTasksCount
  ).filterValues { it != null }
}
