package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class ActivityLog(
  val id: String = "",
  val userId: String = "",
  val title: String = "",
  val type: String = "habit",
  val xpEarned: Int = 0,
  val date: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null
) {
  fun toMap(): Map<String, Any> = mapOf(
    "id" to id,
    "userId" to userId,
    "title" to title,
    "type" to type,
    "xpEarned" to xpEarned,
    "date" to date
  )
}
