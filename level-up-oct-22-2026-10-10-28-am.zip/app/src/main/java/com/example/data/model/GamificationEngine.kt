package com.example.data.model

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object GamificationEngine {

  /**
   * Calculates XP required to reach the next level from the current level.
   * Level 1 -> 100 XP
   * Level 2 -> 150 XP
   * Level 3 -> 220 XP
   * Level 4 -> 300 XP
   * Level L -> (80 + L * 50 + (L * L * 10))
   */
  fun getXpRequiredForNextLevel(level: Int): Int {
    val lvl = level.coerceAtLeast(1)
    return 80 + (lvl * 50) + (lvl * lvl * 10)
  }

  fun getLevelTitle(level: Int): String {
    return when {
      level <= 2 -> "Novice Adventurer"
      level <= 4 -> "Apprentice Disciple"
      level <= 7 -> "Focused Warrior"
      level <= 11 -> "Habit Knight"
      level <= 15 -> "Discipline Champion"
      level <= 19 -> "Master of Will"
      else -> "Ascended Grandmaster"
    }
  }

  fun getTodayDateString(): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    return sdf.format(Date())
  }

  fun getYesterdayDateString(): String {
    val cal = Calendar.getInstance()
    cal.add(Calendar.DAY_OF_YEAR, -1)
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    return sdf.format(cal.time)
  }

  fun getPastDays(days: Int): List<String> {
    val result = mutableListOf<String>()
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    for (i in (days - 1) downTo 0) {
      val cal = Calendar.getInstance()
      cal.add(Calendar.DAY_OF_YEAR, -i)
      result.add(sdf.format(cal.time))
    }
    return result
  }

  /**
   * Recalculates level and current XP when gaining [addedXp].
   * Returns Triple(newLevel, newCurrentXp, newTotalXp).
   */
  fun calculateLevelProgression(currentLevel: Int, currentXp: Int, totalXp: Int, addedXp: Int): Triple<Int, Int, Int> {
    var lvl = currentLevel.coerceAtLeast(1)
    var xp = currentXp + addedXp
    val newTotal = totalXp + addedXp

    var required = getXpRequiredForNextLevel(lvl)
    while (xp >= required) {
      xp -= required
      lvl += 1
      required = getXpRequiredForNextLevel(lvl)
    }

    return Triple(lvl, xp, newTotal)
  }

  /**
   * Calculates streak length given a list of unique date strings formatted "yyyy-MM-dd".
   */
  fun calculateStreak(completedDates: Collection<String>): Int {
    if (completedDates.isEmpty()) return 0

    val sortedDates = completedDates.distinct().sortedDescending()
    val today = getTodayDateString()
    val yesterday = getYesterdayDateString()

    // Streak must include today or yesterday to still be active
    val firstDate = sortedDates.firstOrNull() ?: return 0
    if (firstDate != today && firstDate != yesterday) {
      return 0
    }

    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    var currentStreak = 0
    val checkCal = Calendar.getInstance()
    if (firstDate == yesterday) {
      checkCal.add(Calendar.DAY_OF_YEAR, -1)
    }

    for (dStr in sortedDates) {
      val expectedStr = sdf.format(checkCal.time)
      if (dStr == expectedStr) {
        currentStreak++
        checkCal.add(Calendar.DAY_OF_YEAR, -1)
      } else if (dStr < expectedStr) {
        break
      }
    }

    return currentStreak
  }

  fun getDefaultAchievements(userId: String): List<Achievement> = listOf(
    Achievement(
      id = "first_step",
      userId = userId,
      badgeKey = "first_step",
      title = "First Step",
      description = "Complete your first habit or task to begin your quest",
      category = "Milestone",
      xpReward = 50,
      unlocked = false,
      progress = 0,
      maxProgress = 1
    ),
    Achievement(
      id = "momentum_3",
      userId = userId,
      badgeKey = "momentum_3",
      title = "Momentum",
      description = "Build a 3-day daily streak",
      category = "Streaks",
      xpReward = 100,
      unlocked = false,
      progress = 0,
      maxProgress = 3
    ),
    Achievement(
      id = "seven_day_warrior",
      userId = userId,
      badgeKey = "seven_day_warrior",
      title = "Seven-Day Warrior",
      description = "Maintain an uninterrupted 7-day streak",
      category = "Streaks",
      xpReward = 200,
      unlocked = false,
      progress = 0,
      maxProgress = 7
    ),
    Achievement(
      id = "task_hunter_5",
      userId = userId,
      badgeKey = "task_hunter_5",
      title = "Task Hunter",
      description = "Clear 5 productivity tasks from your board",
      category = "Tasks",
      xpReward = 150,
      unlocked = false,
      progress = 0,
      maxProgress = 5
    ),
    Achievement(
      id = "knowledge_seeker",
      userId = userId,
      badgeKey = "knowledge_seeker",
      title = "Knowledge Seeker",
      description = "Complete 5 Study or Reading habit sessions",
      category = "Habits",
      xpReward = 120,
      unlocked = false,
      progress = 0,
      maxProgress = 5
    ),
    Achievement(
      id = "developer_mode",
      userId = userId,
      badgeKey = "developer_mode",
      title = "Developer Mode",
      description = "Complete a Programming habit or coding project goal",
      category = "Skills",
      xpReward = 150,
      unlocked = false,
      progress = 0,
      maxProgress = 1
    ),
    Achievement(
      id = "iron_will",
      userId = userId,
      badgeKey = "iron_will",
      title = "Iron Will",
      description = "Complete 5 Fitness or Health workouts",
      category = "Fitness",
      xpReward = 120,
      unlocked = false,
      progress = 0,
      maxProgress = 5
    ),
    Achievement(
      id = "level_five",
      userId = userId,
      badgeKey = "level_five",
      title = "Level Five Vanguard",
      description = "Ascend to Player Level 5",
      category = "Level",
      xpReward = 250,
      unlocked = false,
      progress = 1,
      maxProgress = 5
    ),
    Achievement(
      id = "consistency_master",
      userId = userId,
      badgeKey = "consistency_master",
      title = "Consistency Master",
      description = "Complete 30 total habits across your journey",
      category = "Mastery",
      xpReward = 500,
      unlocked = false,
      progress = 0,
      maxProgress = 30
    )
  )

  fun getInitialSampleHabits(userId: String): List<Habit> = listOf(
    Habit(
      id = "sample_habit_study",
      userId = userId,
      name = "Study mathematics & CS",
      description = "Daily focused study sprint",
      category = "Study",
      iconName = "auto_stories",
      xpReward = 35,
      targetDurationOrQuantity = "45 mins",
      frequency = "Daily"
    ),
    Habit(
      id = "sample_habit_code",
      userId = userId,
      name = "Practice programming",
      description = "Write clean code, solve problems or build projects",
      category = "Programming",
      iconName = "terminal",
      xpReward = 40,
      targetDurationOrQuantity = "1 hour",
      frequency = "Daily"
    ),
    Habit(
      id = "sample_habit_read",
      userId = userId,
      name = "Read non-fiction",
      description = "Expand mind with 20 minutes of reading",
      category = "Reading",
      iconName = "menu_book",
      xpReward = 25,
      targetDurationOrQuantity = "20 mins",
      frequency = "Daily"
    ),
    Habit(
      id = "sample_habit_exercise",
      userId = userId,
      name = "Exercise & Calisthenics",
      description = "Strength training or cardio session",
      category = "Fitness",
      iconName = "fitness_center",
      xpReward = 45,
      targetDurationOrQuantity = "30 mins",
      frequency = "Daily"
    ),
    Habit(
      id = "sample_habit_creativity",
      userId = userId,
      name = "Practice guitar / creative work",
      description = "Creativity sprint and musical practice",
      category = "Creativity",
      iconName = "music_note",
      xpReward = 30,
      targetDurationOrQuantity = "25 mins",
      frequency = "Daily"
    )
  )

  fun getInitialSampleTasks(userId: String): List<TaskItem> = listOf(
    TaskItem(
      id = "sample_task_1",
      userId = userId,
      title = "Complete Jetpack Compose architecture module",
      description = "Review state management and unidirectional data flow",
      category = "Programming",
      priority = "High",
      xpReward = 60,
      dueDate = getTodayDateString()
    ),
    TaskItem(
      id = "sample_task_2",
      userId = userId,
      title = "Solve 2 algorithm challenges",
      description = "Practice dynamic programming and graphs",
      category = "Study",
      priority = "Medium",
      xpReward = 45,
      dueDate = getTodayDateString()
    ),
    TaskItem(
      id = "sample_task_3",
      userId = userId,
      title = "Plan weekly workout splits and nutrition",
      description = "Prepare meal prep and gym schedule",
      category = "Fitness",
      priority = "Low",
      xpReward = 25,
      dueDate = getTodayDateString()
    )
  )

  fun getInitialSampleGoals(userId: String): List<Goal> = listOf(
    Goal(
      id = "sample_goal_1",
      userId = userId,
      title = "Master Modern Android & Compose",
      description = "Build 5 full production features with clean architecture",
      category = "Programming",
      timeframe = "Monthly",
      targetValue = 5,
      currentValue = 2,
      unit = "projects",
      xpReward = 300
    ),
    Goal(
      id = "sample_goal_2",
      userId = userId,
      title = "Complete 3 Technical Books",
      description = "Read deep architecture and system design books",
      category = "Reading",
      timeframe = "Long-term",
      targetValue = 3,
      currentValue = 1,
      unit = "books",
      xpReward = 450
    )
  )
}
