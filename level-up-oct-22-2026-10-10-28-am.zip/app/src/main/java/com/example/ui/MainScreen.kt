package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.FlameStreak
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.LevelUpEvent
import com.example.viewmodel.LevelUpViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

enum class ScreenDestination(val title: String, val icon: ImageVector) {
  DASHBOARD("Home", Icons.Default.Home),
  HABITS("Habits", Icons.AutoMirrored.Filled.MenuBook),
  TASKS("Tasks", Icons.Default.CheckCircle),
  GOALS("Goals", Icons.Default.Flag),
  ANALYTICS("Stats", Icons.Default.BarChart),
  ACHIEVEMENTS("Badges", Icons.Default.EmojiEvents),
  HISTORY("History", Icons.Default.History),
  AI_COACH("Coach", Icons.Default.AutoAwesome),
  PROFILE("Profile", Icons.Default.AccountCircle)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
  viewModel: LevelUpViewModel,
  onSignOutComplete: () -> Unit
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val credentialManager = remember { CredentialManager.create(context) }
  val snackbarHostState = remember { SnackbarHostState() }

  var currentScreen by remember { mutableStateOf(ScreenDestination.DASHBOARD) }
  var celebrationDialogData by remember { mutableStateOf<Pair<Int, String>?>(null) }

  // Quick dialog triggers from Dashboard
  var openCreateHabitDialog by remember { mutableStateOf(false) }
  var openCreateTaskDialog by remember { mutableStateOf(false) }

  val userProfile by viewModel.userProfile.collectAsState()
  val habits by viewModel.habits.collectAsState()
  val tasks by viewModel.tasksState.collectAsState()
  val goals by viewModel.goals.collectAsState()
  val activityLogs by viewModel.activityLogs.collectAsState()
  val achievements by viewModel.achievements.collectAsState()
  val aiCoachMessage by viewModel.aiCoachMessage.collectAsState()
  val isAiLoading by viewModel.isAiLoading.collectAsState()

  val selectedHabitCategory by viewModel.selectedHabitCategory.collectAsState()
  val selectedTaskFilter by viewModel.selectedTaskFilter.collectAsState()
  val selectedGoalTimeframe by viewModel.selectedGoalTimeframe.collectAsState()

  // Handle Back Button
  BackHandler(enabled = currentScreen != ScreenDestination.DASHBOARD) {
    currentScreen = ScreenDestination.DASHBOARD
  }

  // Listen for ViewModel Events
  LaunchedEffect(Unit) {
    viewModel.events.collectLatest { event ->
      when (event) {
        is LevelUpEvent.LevelUpCelebration -> {
          celebrationDialogData = Pair(event.newLevel, event.title)
        }
        is LevelUpEvent.AchievementUnlocked -> {
          snackbarHostState.showSnackbar("🏅 Achievement Unlocked: ${event.achievement.title} (+${event.achievement.xpReward} XP)")
        }
        is LevelUpEvent.Message -> {
          snackbarHostState.showSnackbar(event.text)
        }
      }
    }
  }

  val config = LocalConfiguration.current
  val isExpandedScreen = config.screenWidthDp >= 600

  Row(modifier = Modifier.fillMaxSize().background(DarkBackground)) {
    // Large Screen Navigation Rail
    if (isExpandedScreen) {
      NavigationRail(
        containerColor = DarkSurface,
        contentColor = TextSecondary,
        modifier = Modifier.statusBarsPadding().navigationBarsPadding()
      ) {
        Spacer(modifier = Modifier.height(16.dp))
        Image(
          painter = painterResource(id = R.drawable.ic_app_logo),
          contentDescription = "Logo",
          modifier = Modifier.size(36.dp)
        )
        Spacer(modifier = Modifier.height(20.dp))
        ScreenDestination.values().forEach { destination ->
          val isSelected = destination == currentScreen
          NavigationRailItem(
            selected = isSelected,
            onClick = { currentScreen = destination },
            icon = { Icon(imageVector = destination.icon, contentDescription = destination.title) },
            label = { Text(destination.title, fontSize = 10.sp) },
            colors = NavigationRailItemDefaults.colors(
              selectedIconColor = Color(0xFF1E1700),
              selectedTextColor = GoldLight,
              indicatorColor = GoldPrimary,
              unselectedIconColor = TextSecondary,
              unselectedTextColor = TextSecondary
            )
          )
        }
      }
    }

    Scaffold(
      modifier = Modifier.weight(1f),
      containerColor = DarkBackground,
      snackbarHost = { SnackbarHost(snackbarHostState) },
      topBar = {
        TopAppBar(
          title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Image(
                painter = painterResource(id = R.drawable.ic_app_logo),
                contentDescription = null,
                modifier = Modifier.size(28.dp)
              )
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = "LEVEL UP",
                style = MaterialTheme.typography.titleLarge.copy(
                  fontWeight = FontWeight.Black,
                  letterSpacing = 1.sp,
                  brush = Brush.horizontalGradient(listOf(GoldLight, GoldPrimary))
                )
              )
            }
          },
          actions = {
            val streak = userProfile?.currentStreak ?: 0
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFF281504),
              border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(FlameStreak, GoldPrimary)))
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.LocalFireDepartment,
                  contentDescription = null,
                  tint = FlameStreak,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "$streak d",
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = GoldLight)
                )
              }
            }
            Spacer(modifier = Modifier.width(12.dp))
          },
          colors = TopAppBarDefaults.topAppBarColors(
            containerColor = DarkSurface,
            titleContentColor = TextPrimary
          )
        )
      },
      bottomBar = {
        if (!isExpandedScreen) {
          NavigationBar(
            containerColor = DarkSurface,
            contentColor = TextSecondary,
            modifier = Modifier.navigationBarsPadding()
          ) {
            val primaryNavItems = listOf(
              ScreenDestination.DASHBOARD,
              ScreenDestination.HABITS,
              ScreenDestination.TASKS,
              ScreenDestination.GOALS,
              ScreenDestination.ANALYTICS,
              ScreenDestination.AI_COACH,
              ScreenDestination.PROFILE
            )
            primaryNavItems.forEach { destination ->
              val isSelected = destination == currentScreen
              NavigationBarItem(
                selected = isSelected,
                onClick = { currentScreen = destination },
                icon = {
                  Icon(
                    imageVector = destination.icon,
                    contentDescription = destination.title,
                    modifier = Modifier.size(22.dp)
                  )
                },
                label = {
                  Text(
                    text = destination.title,
                    style = MaterialTheme.typography.labelSmall.copy(
                      fontSize = 9.sp,
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    ),
                    maxLines = 1
                  )
                },
                colors = NavigationBarItemDefaults.colors(
                  selectedIconColor = Color(0xFF1E1700),
                  selectedTextColor = GoldLight,
                  indicatorColor = GoldPrimary,
                  unselectedIconColor = TextSecondary,
                  unselectedTextColor = TextSecondary
                ),
                modifier = Modifier.testTag("nav_${destination.name.lowercase()}")
              )
            }
          }
        }
      }
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        when (currentScreen) {
          ScreenDestination.DASHBOARD -> DashboardScreen(
            userProfile = userProfile,
            habits = habits,
            tasks = tasks,
            achievements = achievements,
            onToggleHabit = { viewModel.toggleHabitCompletion(it) },
            onToggleTask = { viewModel.toggleTaskCompletion(it) },
            onNavigateToHabits = { currentScreen = ScreenDestination.HABITS },
            onNavigateToTasks = { currentScreen = ScreenDestination.TASKS },
            onNavigateToGoals = { currentScreen = ScreenDestination.GOALS },
            onNavigateToAiCoach = { currentScreen = ScreenDestination.AI_COACH },
            onNavigateToAchievements = { currentScreen = ScreenDestination.ACHIEVEMENTS },
            onOpenCreateHabit = { openCreateHabitDialog = true },
            onOpenCreateTask = { openCreateTaskDialog = true }
          )
          ScreenDestination.HABITS -> HabitsScreen(
            habits = habits,
            selectedCategory = selectedHabitCategory,
            onSelectCategory = { viewModel.selectedHabitCategory.value = it },
            onToggleHabit = { viewModel.toggleHabitCompletion(it) },
            onSaveHabit = { id, name, desc, cat, xp, target, freq ->
              viewModel.saveHabit(id, name, desc, cat, xp, target, freq)
            },
            onDeleteHabit = { viewModel.deleteHabit(it) }
          )
          ScreenDestination.TASKS -> TasksScreen(
            tasks = tasks,
            selectedFilter = selectedTaskFilter,
            onSelectFilter = { viewModel.selectedTaskFilter.value = it },
            onToggleTask = { viewModel.toggleTaskCompletion(it) },
            onSaveTask = { id, title, desc, cat, priority, due, xp ->
              viewModel.saveTask(id, title, desc, cat, priority, due, xp)
            },
            onDeleteTask = { viewModel.deleteTask(it) }
          )
          ScreenDestination.GOALS -> GoalsScreen(
            goals = goals,
            selectedTimeframe = selectedGoalTimeframe,
            onSelectTimeframe = { viewModel.selectedGoalTimeframe.value = it },
            onUpdateGoalProgress = { goal, newCur -> viewModel.updateGoalProgress(goal, newCur) },
            onSaveGoal = { id, title, desc, cat, tf, target, unit, deadline, xp ->
              viewModel.saveGoal(id, title, desc, cat, tf, target, unit, deadline, xp)
            },
            onDeleteGoal = { viewModel.deleteGoal(it) },
            onBreakdownWithAi = { title, cat ->
              viewModel.breakdownGoalWithAi(title, cat)
              currentScreen = ScreenDestination.AI_COACH
            }
          )
          ScreenDestination.ANALYTICS -> AnalyticsScreen(
            userProfile = userProfile,
            habits = habits,
            tasks = tasks,
            activityLogs = activityLogs
          )
          ScreenDestination.ACHIEVEMENTS -> AchievementsScreen(
            achievements = achievements
          )
          ScreenDestination.HISTORY -> HistoryScreen(
            activityLogs = activityLogs
          )
          ScreenDestination.AI_COACH -> AiCoachScreen(
            coachMessage = aiCoachMessage,
            isLoading = isAiLoading,
            onGenerateDailyQuest = { viewModel.generateAiDailyQuest() },
            onAskQuestion = { viewModel.askAiCoach(it) },
            onClearMessage = { viewModel.clearAiMessage() }
          )
          ScreenDestination.PROFILE -> ProfileScreen(
            userProfile = userProfile,
            onSignOut = {
              signOutUser(
                context = context,
                credentialManager = credentialManager,
                onSignOutComplete = onSignOutComplete,
                scope = coroutineScope
              )
            }
          )
        }

        // Quick dialog for Creating Habit
        if (openCreateHabitDialog) {
          HabitFormDialog(
            initialHabit = null,
            onDismiss = { openCreateHabitDialog = false },
            onSave = { name, desc, category, xp, target, freq ->
              viewModel.saveHabit("", name, desc, category, xp, target, freq)
              openCreateHabitDialog = false
            }
          )
        }

        // Quick dialog for Creating Task
        if (openCreateTaskDialog) {
          TaskFormDialog(
            initialTask = null,
            onDismiss = { openCreateTaskDialog = false },
            onSave = { title, desc, cat, priority, due, xp ->
              viewModel.saveTask("", title, desc, cat, priority, due, xp)
              openCreateTaskDialog = false
            }
          )
        }

        // Level Up Celebration Dialog
        celebrationDialogData?.let { (level, title) ->
          LevelUpDialog(
            newLevel = level,
            title = title,
            onDismiss = { celebrationDialogData = null }
          )
        }
      }
    }
  }
}
