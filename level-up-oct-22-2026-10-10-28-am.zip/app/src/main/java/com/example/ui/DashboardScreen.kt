package com.example.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Achievement
import com.example.data.model.GamificationEngine
import com.example.data.model.Habit
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkCardSurfaceElevated
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.FlameStreak
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent
import java.util.Calendar

@Composable
fun DashboardScreen(
  userProfile: UserProfile?,
  habits: List<Habit>,
  tasks: List<TaskItem>,
  achievements: List<Achievement>,
  onToggleHabit: (Habit) -> Unit,
  onToggleTask: (TaskItem) -> Unit,
  onNavigateToHabits: () -> Unit,
  onNavigateToTasks: () -> Unit,
  onNavigateToGoals: () -> Unit,
  onNavigateToAiCoach: () -> Unit,
  onNavigateToAchievements: () -> Unit,
  onOpenCreateHabit: () -> Unit,
  onOpenCreateTask: () -> Unit
) {
  val today = GamificationEngine.getTodayDateString()
  val profile = userProfile ?: UserProfile()
  val level = profile.level
  val currentXp = profile.currentXp
  val requiredXp = GamificationEngine.getXpRequiredForNextLevel(level)
  val progressFraction = (currentXp.toFloat() / requiredXp.toFloat()).coerceIn(0f, 1f)
  val animatedProgress by animateFloatAsState(targetValue = progressFraction, label = "xp_progress")

  val completedHabitsToday = habits.count { it.isCompletedOn(today) }
  val totalHabitsToday = habits.count { !it.archived }
  val habitsCompletionPercent = if (totalHabitsToday > 0) {
    ((completedHabitsToday.toFloat() / totalHabitsToday.toFloat()) * 100).toInt()
  } else 0

  val greeting = rememberGreeting()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(8.dp))
      // User Greeting & Level Card
      HeroLevelCard(
        greeting = greeting,
        displayName = profile.displayName,
        level = level,
        levelTitle = GamificationEngine.getLevelTitle(level),
        currentXp = currentXp,
        requiredXp = requiredXp,
        progress = animatedProgress,
        totalXp = profile.totalXp,
        streak = profile.currentStreak,
        bestStreak = profile.bestStreak
      )
    }

    item {
      // Daily Mission Card & Quick Progress
      DailyMissionAndProgressCard(
        completedToday = completedHabitsToday,
        totalToday = totalHabitsToday,
        percent = habitsCompletionPercent,
        onAskQuestmaster = onNavigateToAiCoach
      )
    }

    item {
      // Quick Actions Row
      QuickActionsRow(
        onAddHabit = onOpenCreateHabit,
        onAddTask = onOpenCreateTask,
        onAddGoal = onNavigateToGoals,
        onAiCoach = onNavigateToAiCoach
      )
    }

    item {
      // Today's Habits Section Header
      SectionHeader(
        title = "Today's Habits ($completedHabitsToday/$totalHabitsToday)",
        actionLabel = "View All",
        onAction = onNavigateToHabits
      )
    }

    if (habits.isEmpty()) {
      item {
        EmptyDashboardState(
          title = "No habits created yet",
          description = "Create your first daily habit to start earning XP and leveling up!",
          actionLabel = "+ Create First Habit",
          onAction = onOpenCreateHabit
        )
      }
    } else {
      items(habits.size) { index ->
        val habit = habits[index]
        HabitDashboardItem(
          habit = habit,
          isCompletedToday = habit.isCompletedOn(today),
          onToggle = { onToggleHabit(habit) }
        )
      }
    }

    item {
      // Priority Tasks Section Header
      SectionHeader(
        title = "Today's Tasks",
        actionLabel = "View All",
        onAction = onNavigateToTasks
      )
    }

    val pendingTasks = tasks.filter { !it.isCompleted }.take(4)
    if (pendingTasks.isEmpty()) {
      item {
        EmptyDashboardState(
          title = "No pending tasks",
          description = "You're all caught up on your quests! Add a new task to conquer.",
          actionLabel = "+ Add New Task",
          onAction = onOpenCreateTask
        )
      }
    } else {
      items(pendingTasks.size) { index ->
        val task = pendingTasks[index]
        TaskDashboardItem(
          task = task,
          onToggle = { onToggleTask(task) }
        )
      }
    }

    item {
      // Recent Achievements Showcase
      SectionHeader(
        title = "Achievements Gallery",
        actionLabel = "Gallery",
        onAction = onNavigateToAchievements
      )
      AchievementsPreviewRow(
        achievements = achievements,
        onViewAll = onNavigateToAchievements
      )
      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}

@Composable
private fun HeroLevelCard(
  greeting: String,
  displayName: String,
  level: Int,
  levelTitle: String,
  currentXp: Int,
  requiredXp: Int,
  progress: Float,
  totalXp: Int,
  streak: Int,
  bestStreak: Int
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("hero_level_card"),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = DarkCardSurfaceElevated),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.linearGradient(
        listOf(GoldPrimary.copy(alpha = 0.5f), DarkCardBorder)
      )
    )
  ) {
    Column(modifier = Modifier.padding(20.dp)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Column {
          Text(
            text = "$greeting,",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
          )
          Text(
            text = displayName,
            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
            color = TextPrimary
          )
        }

        // Streak Pill
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFF2B1605),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(FlameStreak, GoldPrimary)))
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Icon(
              imageVector = Icons.Default.LocalFireDepartment,
              contentDescription = null,
              tint = FlameStreak,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Column {
              Text(
                text = "$streak Days",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = GoldLight)
              )
              Text(
                text = "Best: $bestStreak",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Level and Title Row
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .background(Brush.radialGradient(listOf(GoldPrimary, GoldDark))),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "$level",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black, color = Color(0xFF1E1700))
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "LEVEL $level",
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = GoldPrimary,
                letterSpacing = 1.sp
              )
            )
            Text(
              text = levelTitle,
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
              color = TextPrimary
            )
          }
        }

        Text(
          text = "$currentXp / $requiredXp XP",
          style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
          color = GoldLight
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Animated XP Progress Bar
      LinearProgressIndicator(
        progress = { progress },
        modifier = Modifier
          .fillMaxWidth()
          .height(8.dp)
          .clip(RoundedCornerShape(4.dp)),
        color = GoldPrimary,
        trackColor = Color(0xFF1E293B),
        strokeCap = StrokeCap.Round
      )

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = "Total Lifetime XP: $totalXp",
        style = MaterialTheme.typography.labelSmall,
        color = TextMuted
      )
    }
  }
}

@Composable
private fun DailyMissionAndProgressCard(
  completedToday: Int,
  totalToday: Int,
  percent: Int,
  onAskQuestmaster: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.linearGradient(listOf(DarkCardBorder, ElectricBlue.copy(alpha = 0.3f)))
    )
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = ElectricBlue,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Daily Quest & Status",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = TextPrimary
          )
        }

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = if (percent == 100) SuccessGreen.copy(alpha = 0.2f) else ElectricBlue.copy(alpha = 0.2f)
        ) {
          Text(
            text = "$percent% Complete",
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = FontWeight.Bold,
              color = if (percent == 100) SuccessGreen else ElectricBlue
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = if (completedToday == totalToday && totalToday > 0) {
          "🌟 Daily Mastery Achieved! All $totalToday habits conquered today. +50 Bonus XP active."
        } else {
          "Complete all remaining habits today to trigger the 'Flawless Day' +50 Bonus XP multiplier."
        },
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
      )

      Spacer(modifier = Modifier.height(12.dp))

      Button(
        onClick = onAskQuestmaster,
        colors = ButtonDefaults.buttonColors(
          containerColor = Color(0xFF1E293B),
          contentColor = GoldLight
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().testTag("ask_questmaster_button")
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = "Consult AI Questmaster Coach", style = MaterialTheme.typography.labelMedium)
        }
      }
    }
  }
}

@Composable
private fun QuickActionsRow(
  onAddHabit: () -> Unit,
  onAddTask: () -> Unit,
  onAddGoal: () -> Unit,
  onAiCoach: () -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    QuickActionButton(
      label = "+ Habit",
      icon = Icons.Default.Add,
      accent = GoldPrimary,
      modifier = Modifier.weight(1f),
      onClick = onAddHabit
    )
    QuickActionButton(
      label = "+ Task",
      icon = Icons.Default.CheckCircle,
      accent = ElectricBlue,
      modifier = Modifier.weight(1f),
      onClick = onAddTask
    )
    QuickActionButton(
      label = "Goals",
      icon = Icons.Default.Flag,
      accent = VioletAccent,
      modifier = Modifier.weight(1f),
      onClick = onAddGoal
    )
    QuickActionButton(
      label = "AI Coach",
      icon = Icons.Default.AutoAwesome,
      accent = GoldLight,
      modifier = Modifier.weight(1f),
      onClick = onAiCoach
    )
  }
}

@Composable
private fun QuickActionButton(
  label: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  accent: Color,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  Card(
    modifier = modifier
      .clickable(onClick = onClick)
      .testTag("quick_action_${label.replace("+", "").trim()}"),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(DarkCardBorder, accent.copy(alpha = 0.3f))))
  ) {
    Column(
      modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Icon(imageVector = icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
        color = TextPrimary
      )
    }
  }
}

@Composable
fun SectionHeader(
  title: String,
  actionLabel: String,
  onAction: () -> Unit
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
    modifier = Modifier.fillMaxWidth()
  ) {
    Text(
      text = title,
      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
      color = TextPrimary
    )
    Text(
      text = actionLabel,
      style = MaterialTheme.typography.labelMedium.copy(color = GoldPrimary, fontWeight = FontWeight.SemiBold),
      modifier = Modifier
        .clickable(onClick = onAction)
        .padding(4.dp)
    )
  }
}

@Composable
fun HabitDashboardItem(
  habit: Habit,
  isCompletedToday: Boolean,
  onToggle: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onToggle)
      .testTag("habit_card_${habit.id}"),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (isCompletedToday) DarkCardSurface.copy(alpha = 0.6f) else DarkCardSurface
    ),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.linearGradient(
        if (isCompletedToday) listOf(SuccessGreen.copy(alpha = 0.4f), DarkCardBorder)
        else listOf(DarkCardBorder, GoldPrimary.copy(alpha = 0.2f))
      )
    )
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = if (isCompletedToday) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
        contentDescription = if (isCompletedToday) "Completed" else "Incomplete",
        tint = if (isCompletedToday) SuccessGreen else TextSecondary,
        modifier = Modifier.size(26.dp)
      )

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = habit.name,
          style = MaterialTheme.typography.bodyLarge.copy(
            fontWeight = FontWeight.SemiBold,
            color = if (isCompletedToday) TextSecondary else TextPrimary
          )
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = habit.category,
            style = MaterialTheme.typography.labelSmall,
            color = GoldPrimary
          )
          if (habit.targetDurationOrQuantity != null) {
            Text(text = " • ${habit.targetDurationOrQuantity}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
          }
          if (habit.currentStreak > 0) {
            Text(text = " • 🔥 ${habit.currentStreak}d", style = MaterialTheme.typography.labelSmall, color = FlameStreak)
          }
        }
      }

      Surface(
        shape = RoundedCornerShape(6.dp),
        color = GoldPrimary.copy(alpha = 0.15f)
      ) {
        Text(
          text = "+${habit.xpReward} XP",
          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = GoldLight)
        )
      }
    }
  }
}

@Composable
fun TaskDashboardItem(
  task: TaskItem,
  onToggle: () -> Unit
) {
  val priorityColor = when (task.priority.lowercase()) {
    "high" -> Color(0xFFEF4444)
    "medium" -> Color(0xFFF59E0B)
    else -> Color(0xFF10B981)
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onToggle)
      .testTag("task_card_${task.id}"),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.linearGradient(listOf(DarkCardBorder, priorityColor.copy(alpha = 0.3f)))
    )
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
        contentDescription = null,
        tint = if (task.isCompleted) SuccessGreen else TextSecondary,
        modifier = Modifier.size(24.dp)
      )

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = task.title,
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
          color = if (task.isCompleted) TextSecondary else TextPrimary
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = priorityColor.copy(alpha = 0.2f)
          ) {
            Text(
              text = task.priority,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp),
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = priorityColor)
            )
          }
          if (task.dueDate != null) {
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "Due: ${task.dueDate}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
          }
        }
      }

      Text(
        text = "+${task.xpReward} XP",
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = GoldLight)
      )
    }
  }
}

@Composable
fun EmptyDashboardState(
  title: String,
  description: String,
  actionLabel: String,
  onAction: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(DarkCardBorder, DarkCardBorder)))
  ) {
    Column(
      modifier = Modifier.padding(20.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(text = title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
      Spacer(modifier = Modifier.height(4.dp))
      Text(text = description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
      Spacer(modifier = Modifier.height(12.dp))
      Button(
        onClick = onAction,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B), contentColor = GoldPrimary),
        shape = RoundedCornerShape(8.dp)
      ) {
        Text(text = actionLabel, style = MaterialTheme.typography.labelMedium)
      }
    }
  }
}

@Composable
private fun AchievementsPreviewRow(
  achievements: List<Achievement>,
  onViewAll: () -> Unit
) {
  val displayList = achievements.take(4)
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    displayList.forEach { ach ->
      Card(
        modifier = Modifier
          .weight(1f)
          .clickable(onClick = onViewAll),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
          containerColor = if (ach.unlocked) Color(0xFF261D09) else DarkCardSurface
        ),
        border = CardDefaults.outlinedCardBorder().copy(
          brush = Brush.linearGradient(
            if (ach.unlocked) listOf(GoldLight, GoldDark) else listOf(DarkCardBorder, DarkCardBorder)
          )
        )
      ) {
        Column(
          modifier = Modifier.padding(10.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Icon(
            imageVector = if (ach.unlocked) Icons.Default.WorkspacePremium else Icons.Default.EmojiEvents,
            contentDescription = null,
            tint = if (ach.unlocked) GoldLight else TextMuted,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = ach.title,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = if (ach.unlocked) GoldLight else TextSecondary,
            maxLines = 1
          )
        }
      }
    }
  }
}

@Composable
fun rememberGreeting(): String {
  val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
  return when (hour) {
    in 4..11 -> "Good morning"
    in 12..16 -> "Good afternoon"
    in 17..22 -> "Good evening"
    else -> "Greetings, Night Owl"
  }
}
