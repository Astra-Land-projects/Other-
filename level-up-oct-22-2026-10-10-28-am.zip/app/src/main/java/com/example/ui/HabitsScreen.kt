package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.GamificationEngine
import com.example.data.model.Habit
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkCardSurfaceElevated
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.FlameStreak
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent

val HabitCategories = listOf(
  "All",
  "Study",
  "Programming",
  "Fitness",
  "Reading",
  "Creativity",
  "Wellness",
  "Custom"
)

@Composable
fun HabitsScreen(
  habits: List<Habit>,
  selectedCategory: String,
  onSelectCategory: (String) -> Unit,
  onToggleHabit: (Habit) -> Unit,
  onSaveHabit: (id: String, name: String, desc: String, category: String, xp: Int, target: String, freq: String) -> Unit,
  onDeleteHabit: (String) -> Unit
) {
  var showCreateDialog by remember { mutableStateOf(false) }
  var habitToEdit by remember { mutableStateOf<Habit?>(null) }
  var habitToDelete by remember { mutableStateOf<Habit?>(null) }

  val today = GamificationEngine.getTodayDateString()
  val filteredHabits = habits.filter {
    (selectedCategory == "All" || it.category.equals(selectedCategory, ignoreCase = true)) && !it.archived
  }

  Box(modifier = Modifier.fillMaxSize()) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp)
    ) {
      Text(
        text = "Habits & Disciplines",
        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
        color = TextPrimary,
        modifier = Modifier.padding(top = 8.dp)
      )
      Text(
        text = "Build recurring daily rituals. Earn XP and protect your streaks.",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Category Filter Chips
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(HabitCategories) { cat ->
          val isSelected = cat == selectedCategory
          FilterChip(
            selected = isSelected,
            onClick = { onSelectCategory(cat) },
            label = {
              Text(
                text = cat,
                style = MaterialTheme.typography.labelMedium.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = GoldPrimary,
              selectedLabelColor = Color(0xFF1E1700),
              containerColor = DarkCardSurface,
              labelColor = TextSecondary
            ),
            border = FilterChipDefaults.filterChipBorder(
              enabled = true,
              selected = isSelected,
              borderColor = DarkCardBorder,
              selectedBorderColor = GoldLight
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      if (filteredHabits.isEmpty()) {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 24.dp),
          colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
          shape = RoundedCornerShape(16.dp),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(DarkCardBorder, DarkCardBorder)))
        ) {
          Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = if (selectedCategory == "All") "No habits found" else "No habits in $selectedCategory",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = TextPrimary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "Tap the + button below to forge a new habit and start earning XP.",
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary
            )
          }
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(12.dp),
          modifier = Modifier.fillMaxSize()
        ) {
          items(filteredHabits, key = { it.id }) { habit ->
            HabitCard(
              habit = habit,
              isCompletedToday = habit.isCompletedOn(today),
              onToggle = { onToggleHabit(habit) },
              onEdit = { habitToEdit = habit },
              onDelete = { habitToDelete = habit }
            )
          }
          item {
            Spacer(modifier = Modifier.height(80.dp))
          }
        }
      }
    }

    // FAB to Add Habit
    FloatingActionButton(
      onClick = { showCreateDialog = true },
      containerColor = GoldPrimary,
      contentColor = Color(0xFF1E1700),
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(20.dp)
        .testTag("add_habit_fab")
    ) {
      Icon(imageVector = Icons.Default.Add, contentDescription = "Add Habit")
    }

    // Create or Edit Dialog
    if (showCreateDialog || habitToEdit != null) {
      val habit = habitToEdit
      HabitFormDialog(
        initialHabit = habit,
        onDismiss = {
          showCreateDialog = false
          habitToEdit = null
        },
        onSave = { name, desc, category, xp, target, freq ->
          onSaveHabit(habit?.id ?: "", name, desc, category, xp, target, freq)
          showCreateDialog = false
          habitToEdit = null
        }
      )
    }

    // Delete Confirmation
    if (habitToDelete != null) {
      AlertDialog(
        onDismissRequest = { habitToDelete = null },
        title = { Text("Delete Habit", color = TextPrimary) },
        text = { Text("Are you sure you want to delete '${habitToDelete?.name}'? History for this habit will be removed.", color = TextSecondary) },
        confirmButton = {
          Button(
            onClick = {
              habitToDelete?.id?.let { onDeleteHabit(it) }
              habitToDelete = null
            },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
          ) {
            Text("Delete", color = Color.White)
          }
        },
        dismissButton = {
          TextButton(onClick = { habitToDelete = null }) {
            Text("Cancel", color = TextSecondary)
          }
        },
        containerColor = DarkCardSurfaceElevated
      )
    }
  }
}

@Composable
fun HabitCard(
  habit: Habit,
  isCompletedToday: Boolean,
  onToggle: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit
) {
  val categoryIcon = getCategoryIcon(habit.category)

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("habit_card_${habit.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (isCompletedToday) DarkCardSurface.copy(alpha = 0.7f) else DarkCardSurface
    ),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.linearGradient(
        if (isCompletedToday) listOf(SuccessGreen.copy(alpha = 0.5f), DarkCardBorder)
        else listOf(DarkCardBorder, GoldPrimary.copy(alpha = 0.25f))
      )
    )
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          // Category Icon badge
          Box(
            modifier = Modifier
              .size(42.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(
                if (isCompletedToday) SuccessGreen.copy(alpha = 0.15f) else GoldPrimary.copy(alpha = 0.12f)
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = categoryIcon,
              contentDescription = null,
              tint = if (isCompletedToday) SuccessGreen else GoldLight,
              modifier = Modifier.size(22.dp)
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column {
            Text(
              text = habit.name,
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = if (isCompletedToday) TextSecondary else TextPrimary
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = habit.category,
                style = MaterialTheme.typography.labelSmall,
                color = GoldPrimary
              )
              if (habit.targetDurationOrQuantity != null) {
                Text(
                  text = " • ${habit.targetDurationOrQuantity}",
                  style = MaterialTheme.typography.labelSmall,
                  color = TextMuted
                )
              }
            }
          }
        }

        // Toggle button
        IconButton(
          onClick = onToggle,
          modifier = Modifier.testTag("toggle_habit_${habit.id}")
        ) {
          Icon(
            imageVector = if (isCompletedToday) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
            contentDescription = if (isCompletedToday) "Completed" else "Incomplete",
            tint = if (isCompletedToday) SuccessGreen else TextSecondary,
            modifier = Modifier.size(32.dp)
          )
        }
      }

      if (!habit.description.isNullOrBlank()) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = habit.description,
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Footer: Streak, XP Reward, Actions
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFF271708)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Icon(
                imageVector = Icons.Default.LocalFireDepartment,
                contentDescription = null,
                tint = FlameStreak,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "${habit.currentStreak}d Streak (Best: ${habit.bestStreak})",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = GoldLight)
              )
            }
          }

          Spacer(modifier = Modifier.width(8.dp))

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = GoldPrimary.copy(alpha = 0.15f)
          ) {
            Text(
              text = "+${habit.xpReward} XP",
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = GoldLight)
            )
          }
        }

        Row {
          IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
            Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = TextSecondary, modifier = Modifier.size(16.dp))
          }
          IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
          }
        }
      }
    }
  }
}

@Composable
fun HabitFormDialog(
  initialHabit: Habit?,
  onDismiss: () -> Unit,
  onSave: (name: String, desc: String, category: String, xp: Int, target: String, freq: String) -> Unit
) {
  var name by remember { mutableStateOf(initialHabit?.name ?: "") }
  var description by remember { mutableStateOf(initialHabit?.description ?: "") }
  var category by remember { mutableStateOf(initialHabit?.category ?: "Study") }
  var xpReward by remember { mutableIntStateOf(initialHabit?.xpReward ?: 30) }
  var target by remember { mutableStateOf(initialHabit?.targetDurationOrQuantity ?: "") }
  var frequency by remember { mutableStateOf(initialHabit?.frequency ?: "Daily") }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = if (initialHabit == null) "Forge New Habit" else "Edit Habit",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        color = TextPrimary
      )
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Habit Name *") },
          placeholder = { Text("e.g. 45m Focused Coding") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("habit_name_input"),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GoldPrimary,
            unfocusedBorderColor = DarkCardBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          )
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("Description (Optional)") },
          placeholder = { Text("Why this habit matters for your quest") },
          modifier = Modifier.fillMaxWidth(),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GoldPrimary,
            unfocusedBorderColor = DarkCardBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          )
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(text = "Category", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(HabitCategories.filter { it != "All" }) { cat ->
            FilterChip(
              selected = category == cat,
              onClick = { category = cat },
              label = { Text(cat) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = GoldPrimary,
                selectedLabelColor = Color(0xFF1E1700),
                containerColor = DarkCardSurface,
                labelColor = TextSecondary
              )
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = target,
          onValueChange = { target = it },
          label = { Text("Target Duration / Quantity") },
          placeholder = { Text("e.g. 30 mins, 10 pages") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GoldPrimary,
            unfocusedBorderColor = DarkCardBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          )
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(text = "XP Reward: +$xpReward XP", style = MaterialTheme.typography.bodyMedium, color = GoldLight)
          Row {
            Button(
              onClick = { if (xpReward > 10) xpReward -= 5 },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.size(36.dp),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) { Text("-") }
            Spacer(modifier = Modifier.width(6.dp))
            Button(
              onClick = { if (xpReward < 200) xpReward += 5 },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.size(36.dp),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) { Text("+") }
          }
        }

        if (errorMessage != null) {
          Spacer(modifier = Modifier.height(6.dp))
          Text(text = errorMessage ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (name.isBlank()) {
            errorMessage = "Habit name cannot be empty"
          } else {
            onSave(name, description, category, xpReward, target, frequency)
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color(0xFF1E1700)),
        modifier = Modifier.testTag("save_habit_button")
      ) {
        Text("Save Habit", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel", color = TextSecondary)
      }
    },
    containerColor = DarkCardSurfaceElevated
  )
}

fun getCategoryIcon(category: String): ImageVector {
  return when (category.lowercase()) {
    "study", "education" -> Icons.AutoMirrored.Filled.MenuBook
    "programming", "technology" -> Icons.Default.Terminal
    "fitness", "exercise" -> Icons.Default.FitnessCenter
    "reading" -> Icons.AutoMirrored.Filled.MenuBook
    "creativity" -> Icons.Default.MusicNote
    "wellness", "sleep" -> Icons.Default.Spa
    else -> Icons.Default.CheckCircle
  }
}
