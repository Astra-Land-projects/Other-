package com.example.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Goal
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkCardSurfaceElevated
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent

val GoalTimeframes = listOf("All", "Short-term", "Weekly", "Monthly", "Long-term")

@Composable
fun GoalsScreen(
  goals: List<Goal>,
  selectedTimeframe: String,
  onSelectTimeframe: (String) -> Unit,
  onUpdateGoalProgress: (Goal, Int) -> Unit,
  onSaveGoal: (id: String, title: String, desc: String, category: String, timeframe: String, target: Int, unit: String, deadline: String, xp: Int) -> Unit,
  onDeleteGoal: (String) -> Unit,
  onBreakdownWithAi: (String, String) -> Unit
) {
  var showCreateDialog by remember { mutableStateOf(false) }
  var goalToEdit by remember { mutableStateOf<Goal?>(null) }
  var goalToDelete by remember { mutableStateOf<Goal?>(null) }

  val filteredGoals = goals.filter {
    selectedTimeframe == "All" || it.timeframe.equals(selectedTimeframe, ignoreCase = true)
  }

  Box(modifier = Modifier.fillMaxSize()) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp)
    ) {
      Text(
        text = "Major Goals & Milestones",
        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
        color = TextPrimary,
        modifier = Modifier.padding(top = 8.dp)
      )
      Text(
        text = "Track measurable targets with numeric progress. Complete milestones to earn massive XP.",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
      )

      Spacer(modifier = Modifier.height(14.dp))

      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(GoalTimeframes) { tf ->
          val isSelected = tf == selectedTimeframe
          FilterChip(
            selected = isSelected,
            onClick = { onSelectTimeframe(tf) },
            label = {
              Text(
                text = tf,
                style = MaterialTheme.typography.labelMedium.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = GoldPrimary,
              selectedLabelColor = Color(0xFF1E1700),
              containerColor = DarkCardSurface,
              labelColor = TextSecondary
            ),
            border = FilterChipDefaults.filterChipBorder(
              enabled = true,
              selected = isSelected,
              borderColor = DarkCardBorder,
              selectedBorderColor = GoldLight
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      if (filteredGoals.isEmpty()) {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 24.dp),
          colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
          shape = RoundedCornerShape(16.dp),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(DarkCardBorder, DarkCardBorder)))
        ) {
          Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = "No goals set",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = TextPrimary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "Set a high-impact goal to unlock milestones and reach your peak performance.",
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary
            )
          }
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(14.dp),
          modifier = Modifier.fillMaxSize()
        ) {
          items(filteredGoals, key = { it.id }) { goal ->
            GoalCard(
              goal = goal,
              onUpdateProgress = { newProgress -> onUpdateGoalProgress(goal, newProgress) },
              onEdit = { goalToEdit = goal },
              onDelete = { goalToDelete = goal },
              onBreakdown = { onBreakdownWithAi(goal.title, goal.category) }
            )
          }
          item {
            Spacer(modifier = Modifier.height(80.dp))
          }
        }
      }
    }

    // FAB to Add Goal
    FloatingActionButton(
      onClick = { showCreateDialog = true },
      containerColor = GoldPrimary,
      contentColor = Color(0xFF1E1700),
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(20.dp)
        .testTag("add_goal_fab")
    ) {
      Icon(imageVector = Icons.Default.Add, contentDescription = "Add Goal")
    }

    if (showCreateDialog || goalToEdit != null) {
      val goal = goalToEdit
      GoalFormDialog(
        initialGoal = goal,
        onDismiss = {
          showCreateDialog = false
          goalToEdit = null
        },
        onSave = { title, desc, cat, timeframe, target, unit, deadline, xp ->
          onSaveGoal(goal?.id ?: "", title, desc, cat, timeframe, target, unit, deadline, xp)
          showCreateDialog = false
          goalToEdit = null
        }
      )
    }

    if (goalToDelete != null) {
      AlertDialog(
        onDismissRequest = { goalToDelete = null },
        title = { Text("Delete Goal", color = TextPrimary) },
        text = { Text("Are you sure you want to remove the goal '${goalToDelete?.title}'?", color = TextSecondary) },
        confirmButton = {
          Button(
            onClick = {
              goalToDelete?.id?.let { onDeleteGoal(it) }
              goalToDelete = null
            },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
          ) {
            Text("Delete", color = Color.White)
          }
        },
        dismissButton = {
          TextButton(onClick = { goalToDelete = null }) {
            Text("Cancel", color = TextSecondary)
          }
        },
        containerColor = DarkCardSurfaceElevated
      )
    }
  }
}

@Composable
fun GoalCard(
  goal: Goal,
  onUpdateProgress: (Int) -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  onBreakdown: () -> Unit
) {
  val animatedProgress by animateFloatAsState(targetValue = goal.progressFraction, label = "goal_progress")
  val isComplete = goal.isCompleted || goal.currentValue >= goal.targetValue

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("goal_card_${goal.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.linearGradient(
        if (isComplete) listOf(GoldLight, GoldDark)
        else listOf(DarkCardBorder, VioletAccent.copy(alpha = 0.3f))
      )
    )
  ) {
    Column(modifier = Modifier.padding(18.dp)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Icon(
            imageVector = if (isComplete) Icons.Default.EmojiEvents else Icons.Default.Flag,
            contentDescription = null,
            tint = if (isComplete) GoldLight else VioletAccent,
            modifier = Modifier.size(22.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = goal.title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = if (isComplete) GoldLight else TextPrimary
          )
        }

        Surface(
          shape = RoundedCornerShape(6.dp),
          color = if (isComplete) GoldPrimary.copy(alpha = 0.2f) else Color(0xFF1E293B)
        ) {
          Text(
            text = if (isComplete) "ACHIEVED" else "+${goal.xpReward} XP",
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = FontWeight.Bold,
              color = if (isComplete) GoldLight else GoldPrimary
            )
          )
        }
      }

      if (!goal.description.isNullOrBlank()) {
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = goal.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Progress status row
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = "${goal.currentValue} / ${goal.targetValue} ${goal.unit}",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = TextPrimary
        )
        Text(
          text = "${(goal.progressFraction * 100).toInt()}%",
          style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
          color = GoldLight
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      LinearProgressIndicator(
        progress = { animatedProgress },
        modifier = Modifier
          .fillMaxWidth()
          .height(8.dp)
          .clip(RoundedCornerShape(4.dp)),
        color = if (isComplete) GoldLight else GoldPrimary,
        trackColor = Color(0xFF1E293B),
        strokeCap = StrokeCap.Round
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Stepper & Action Controls
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Button(
            onClick = { onUpdateProgress(goal.currentValue - 1) },
            enabled = goal.currentValue > 0,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.size(34.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
          ) { Text("-", style = MaterialTheme.typography.titleMedium) }

          Spacer(modifier = Modifier.width(6.dp))

          Button(
            onClick = { onUpdateProgress(goal.currentValue + 1) },
            enabled = goal.currentValue < goal.targetValue,
            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color(0xFF1E1700)),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.size(34.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
          ) { Text("+", style = MaterialTheme.typography.titleMedium) }

          Spacer(modifier = Modifier.width(10.dp))

          Text(
            text = goal.timeframe,
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted
          )
        }

        Row {
          TextButton(onClick = onBreakdown) {
            Text("AI Plan", style = MaterialTheme.typography.labelSmall, color = VioletAccent)
          }
          IconButton(onClick = onEdit, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = TextSecondary, modifier = Modifier.size(14.dp))
          }
          IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444), modifier = Modifier.size(14.dp))
          }
        }
      }
    }
  }
}

@Composable
fun GoalFormDialog(
  initialGoal: Goal?,
  onDismiss: () -> Unit,
  onSave: (title: String, desc: String, category: String, timeframe: String, target: Int, unit: String, deadline: String, xp: Int) -> Unit
) {
  var title by remember { mutableStateOf(initialGoal?.title ?: "") }
  var description by remember { mutableStateOf(initialGoal?.description ?: "") }
  var category by remember { mutableStateOf(initialGoal?.category ?: "Skills") }
  var timeframe by remember { mutableStateOf(initialGoal?.timeframe ?: "Monthly") }
  var targetValue by remember { mutableIntStateOf(initialGoal?.targetValue ?: 10) }
  var unit by remember { mutableStateOf(initialGoal?.unit ?: "hours") }
  var deadline by remember { mutableStateOf(initialGoal?.deadline ?: "") }
  var xpReward by remember { mutableIntStateOf(initialGoal?.xpReward ?: 150) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = if (initialGoal == null) "Set New Major Goal" else "Edit Goal",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        color = TextPrimary
      )
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Goal Title *") },
          placeholder = { Text("e.g. Master Clean Android Architecture") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("goal_title_input"),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GoldPrimary,
            unfocusedBorderColor = DarkCardBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          )
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("Description (Optional)") },
          modifier = Modifier.fillMaxWidth(),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GoldPrimary,
            unfocusedBorderColor = DarkCardBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          )
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(text = "Timeframe", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(GoalTimeframes.filter { it != "All" }) { tf ->
            FilterChip(
              selected = timeframe == tf,
              onClick = { timeframe = tf },
              label = { Text(tf) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = GoldPrimary,
                selectedLabelColor = Color(0xFF1E1700),
                containerColor = DarkCardSurface,
                labelColor = TextSecondary
              )
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = targetValue.toString(),
            onValueChange = { targetValue = it.toIntOrNull() ?: 1 },
            label = { Text("Target Quantity") },
            singleLine = true,
            modifier = Modifier.weight(1f),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = GoldPrimary,
              unfocusedBorderColor = DarkCardBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            )
          )
          OutlinedTextField(
            value = unit,
            onValueChange = { unit = it },
            label = { Text("Unit (e.g. hours)") },
            singleLine = true,
            modifier = Modifier.weight(1f),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = GoldPrimary,
              unfocusedBorderColor = DarkCardBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            )
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(text = "Completion Reward: +$xpReward XP", style = MaterialTheme.typography.bodyMedium, color = GoldLight)
          Row {
            Button(
              onClick = { if (xpReward > 50) xpReward -= 25 },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.size(36.dp),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) { Text("-") }
            Spacer(modifier = Modifier.width(6.dp))
            Button(
              onClick = { if (xpReward < 1000) xpReward += 25 },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.size(36.dp),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) { Text("+") }
          }
        }

        if (errorMessage != null) {
          Spacer(modifier = Modifier.height(6.dp))
          Text(text = errorMessage ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isBlank()) {
            errorMessage = "Goal title cannot be blank"
          } else {
            onSave(title, description, category, timeframe, targetValue, unit, deadline, xpReward)
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color(0xFF1E1700)),
        modifier = Modifier.testTag("save_goal_button")
      ) {
        Text("Lock In Goal", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel", color = TextSecondary)
      }
    },
    containerColor = DarkCardSurfaceElevated
  )
}
