package com.example.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Achievement
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkCardSurfaceElevated
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun AchievementsScreen(
  achievements: List<Achievement>
) {
  val unlockedCount = achievements.count { it.unlocked }
  val totalCount = achievements.size
  val totalXpFromBadges = achievements.filter { it.unlocked }.sumOf { it.xpReward }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Text(
        text = "Hall of Achievements",
        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
        color = TextPrimary,
        modifier = Modifier.padding(top = 8.dp)
      )
      Text(
        text = "Badges of honor unlocked through continuous discipline.",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Summary Card
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("achievements_summary_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCardSurfaceElevated),
        border = CardDefaults.outlinedCardBorder().copy(
          brush = Brush.linearGradient(listOf(GoldPrimary.copy(alpha = 0.5f), DarkCardBorder))
        )
      ) {
        Row(
          modifier = Modifier.padding(20.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column {
            Text(
              text = "$unlockedCount / $totalCount Badges Unlocked",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = GoldLight
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Total XP Claimed: +$totalXpFromBadges XP",
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary
            )
          }

          Box(
            modifier = Modifier
              .size(54.dp)
              .clip(CircleShape)
              .background(Brush.radialGradient(listOf(GoldPrimary, GoldDark))),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.WorkspacePremium,
              contentDescription = null,
              tint = Color(0xFF1E1700),
              modifier = Modifier.size(30.dp)
            )
          }
        }
      }
    }

    items(achievements, key = { it.id }) { ach ->
      AchievementCard(achievement = ach)
    }

    item {
      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}

@Composable
fun AchievementCard(achievement: Achievement) {
  val isUnlocked = achievement.unlocked
  val progressFraction = achievement.progressFraction
  val animatedProgress by animateFloatAsState(targetValue = progressFraction, label = "badge_progress")

  val icon = getAchievementIcon(achievement.badgeKey)

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("achievement_badge_${achievement.badgeKey}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (isUnlocked) Color(0xFF1F1808) else DarkCardSurface
    ),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.linearGradient(
        if (isUnlocked) listOf(GoldLight, GoldDark)
        else listOf(DarkCardBorder, DarkCardBorder)
      )
    )
  ) {
    Row(
      modifier = Modifier.padding(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Badge Crest
      Box(
        modifier = Modifier
          .size(54.dp)
          .clip(CircleShape)
          .background(
            if (isUnlocked) Brush.radialGradient(listOf(GoldPrimary.copy(alpha = 0.35f), Color(0xFF141005)))
            else Brush.radialGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A)))
          )
          .border(
            width = 1.5.dp,
            color = if (isUnlocked) GoldPrimary else DarkCardBorder,
            shape = CircleShape
          ),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = if (isUnlocked) icon else Icons.Default.Lock,
          contentDescription = null,
          tint = if (isUnlocked) GoldLight else TextMuted,
          modifier = Modifier.size(26.dp)
        )
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = achievement.title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = if (isUnlocked) GoldLight else TextPrimary
          )

          Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (isUnlocked) GoldPrimary.copy(alpha = 0.2f) else Color(0xFF1E293B)
          ) {
            Text(
              text = if (isUnlocked) "UNLOCKED" else "+${achievement.xpReward} XP",
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = if (isUnlocked) GoldLight else TextSecondary
              )
            )
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = achievement.description,
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (isUnlocked) {
          val dateText = achievement.unlockedAt?.toDate()?.let {
            val sdf = SimpleDateFormat("MMM d, yyyy", Locale.US)
            "Earned on ${sdf.format(it)}"
          } ?: "Unlocked"
          Text(
            text = "✨ $dateText",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = GoldPrimary
          )
        } else {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            LinearProgressIndicator(
              progress = { animatedProgress },
              modifier = Modifier
                .weight(1f)
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
              color = GoldPrimary,
              trackColor = Color(0xFF1E293B),
              strokeCap = StrokeCap.Round
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "${achievement.progress} / ${achievement.maxProgress}",
              style = MaterialTheme.typography.labelSmall,
              color = TextMuted
            )
          }
        }
      }
    }
  }
}

fun getAchievementIcon(key: String): ImageVector {
  return when {
    key.contains("study") || key.contains("knowledge") -> Icons.AutoMirrored.Filled.MenuBook
    key.contains("developer") || key.contains("code") -> Icons.Default.Terminal
    key.contains("fitness") || key.contains("iron") -> Icons.Default.FitnessCenter
    key.contains("level") -> Icons.Default.MilitaryTech
    else -> Icons.Default.AutoAwesome
  }
}
