package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.GamificationEngine
import com.example.data.model.UserProfile
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkCardSurfaceElevated
import com.example.ui.theme.FlameStreak
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ProfileScreen(
  userProfile: UserProfile?,
  onSignOut: () -> Unit
) {
  val profile = userProfile ?: UserProfile()
  val level = profile.level
  val title = GamificationEngine.getLevelTitle(level)

  var dailyReminders by remember { mutableStateOf(true) }
  var streakProtectionSound by remember { mutableStateOf(true) }
  var showExportDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Text(
        text = "Adventurer Profile & Settings",
        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
        color = TextPrimary,
        modifier = Modifier.padding(top = 8.dp)
      )
      Text(
        text = "Manage your player account, cloud sync status, and preferences.",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
      )

      Spacer(modifier = Modifier.height(14.dp))

      // User Card
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("profile_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCardSurfaceElevated),
        border = CardDefaults.outlinedCardBorder().copy(
          brush = Brush.linearGradient(listOf(GoldPrimary.copy(alpha = 0.5f), DarkCardBorder))
        )
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Box(
            modifier = Modifier
              .size(80.dp)
              .clip(CircleShape)
              .background(Brush.radialGradient(listOf(GoldPrimary, GoldDark)))
              .border(2.dp, GoldLight, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Image(
              painter = painterResource(id = R.drawable.ic_app_logo),
              contentDescription = "Profile Avatar",
              modifier = Modifier.size(60.dp)
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          Text(
            text = profile.displayName,
            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
            color = TextPrimary
          )

          if (!profile.email.isNullOrBlank()) {
            Text(
              text = profile.email,
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = GoldPrimary.copy(alpha = 0.15f),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(GoldLight, GoldDark)))
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
              Icon(imageVector = Icons.Default.MilitaryTech, contentDescription = null, tint = GoldLight, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Level $level • $title",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = GoldLight)
              )
            }
          }
        }
      }
    }

    item {
      // RPG Statistics Breakdown
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(DarkCardBorder, DarkCardBorder)))
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Text(
            text = "Player Statistics",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = TextPrimary
          )
          Spacer(modifier = Modifier.height(14.dp))
          ProfileStatRow("Lifetime XP Earned", "${profile.totalXp} XP", GoldLight)
          ProfileStatRow("Current Streak", "${profile.currentStreak} Days", FlameStreak)
          ProfileStatRow("Best Historical Streak", "${profile.bestStreak} Days", GoldPrimary)
          ProfileStatRow("Completed Habits", "${profile.completedHabitsCount}", TextPrimary)
          ProfileStatRow("Completed Tasks", "${profile.completedTasksCount}", TextPrimary)
        }
      }
    }

    item {
      // Preferences & Settings Card
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(DarkCardBorder, DarkCardBorder)))
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Text(
            text = "App Settings & Preferences",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = TextPrimary
          )
          Spacer(modifier = Modifier.height(14.dp))

          // Daily Reminders Toggle
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.Notifications, contentDescription = null, tint = GoldLight)
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(text = "Daily Habit Reminders", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), color = TextPrimary)
                Text(text = "Notifications for morning ritual", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
              }
            }
            Switch(
              checked = dailyReminders,
              onCheckedChange = { dailyReminders = it },
              colors = SwitchDefaults.colors(
                checkedThumbColor = GoldLight,
                checkedTrackColor = GoldPrimary.copy(alpha = 0.5f)
              )
            )
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Theme Display
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.Palette, contentDescription = null, tint = GoldPrimary)
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(text = "Visual Theme", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), color = TextPrimary)
                Text(text = "Obsidian Black & Metallic Gold", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
              }
            }
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = GoldPrimary.copy(alpha = 0.2f)
            ) {
              Text(
                text = "Active",
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = GoldLight)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Cloud Sync Indicator
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.CloudDone, contentDescription = null, tint = Color(0xFF10B981))
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(text = "Cloud Sync", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), color = TextPrimary)
                Text(text = "Connected to Firebase Firestore", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
              }
            }
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = Color(0xFF10B981).copy(alpha = 0.2f)
            ) {
              Text(
                text = "Live",
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
              )
            }
          }
        }
      }
    }

    item {
      // Sign Out Button
      Button(
        onClick = onSignOut,
        colors = ButtonDefaults.buttonColors(
          containerColor = Color(0xFF2B1214),
          contentColor = Color(0xFFEF4444)
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("sign_out_button")
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(imageVector = Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "Sign Out of LEVEL UP", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        }
      }

      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}

@Composable
private fun ProfileStatRow(label: String, value: String, valueColor: Color) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(text = label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
    Text(text = value, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = valueColor)
  }
}
