package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LevelUpColorScheme = darkColorScheme(
  primary = GoldPrimary,
  onPrimary = Color(0xFF1E1700),
  primaryContainer = GoldContainer,
  onPrimaryContainer = OnGoldContainer,

  secondary = ElectricBlue,
  onSecondary = Color.White,
  secondaryContainer = ElectricBlueContainer,
  onSecondaryContainer = ElectricBlueLight,

  tertiary = VioletAccent,
  onTertiary = Color.White,
  tertiaryContainer = VioletContainer,
  onTertiaryContainer = VioletLight,

  background = DarkBackground,
  onBackground = TextPrimary,

  surface = DarkSurface,
  onSurface = TextPrimary,

  surfaceVariant = DarkSurfaceVariant,
  onSurfaceVariant = TextSecondary,

  outline = DarkCardBorder,
  outlineVariant = Color(0xFF1E293B),

  error = ErrorRed,
  onError = Color.White
)

@Composable
fun LevelUpTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = LevelUpColorScheme,
    typography = Typography,
    content = content
  )
}
