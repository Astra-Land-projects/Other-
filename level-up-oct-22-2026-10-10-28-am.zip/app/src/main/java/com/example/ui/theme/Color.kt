package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Backgrounds & Surfaces (Deep black and midnight-navy)
val DarkBackground = Color(0xFF06090E)
val DarkSurface = Color(0xFF0B0F19)
val DarkSurfaceVariant = Color(0xFF131B2B)
val DarkCardBorder = Color(0xFF1E293B)
val DarkCardSurface = Color(0xFF0E1524)
val DarkCardSurfaceElevated = Color(0xFF162033)

// Primary Accent - Metallic Gold
val GoldPrimary = Color(0xFFF59E0B)
val GoldLight = Color(0xFFFCD34D)
val GoldDark = Color(0xFFD97706)
val GoldContainer = Color(0xFF332305)
val OnGoldContainer = Color(0xFFFDE68A)

// Secondary Accents - Electric Blue & Violet
val ElectricBlue = Color(0xFF3B82F6)
val ElectricBlueLight = Color(0xFF60A5FA)
val ElectricBlueContainer = Color(0xFF1E3A8A)
val VioletAccent = Color(0xFF8B5CF6)
val VioletLight = Color(0xFFC4B5FD)
val VioletContainer = Color(0xFF4C1D95)

// Status & Indicators
val FlameStreak = Color(0xFFFF6B00)
val FlameStreakLight = Color(0xFFFFA040)
val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)
val XpGold = Color(0xFFFFD700)

// Text Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val TextMuted = Color(0xFF475569)
