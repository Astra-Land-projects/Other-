package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ActivityLog
import com.example.data.model.GamificationEngine
import com.example.data.model.Habit
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkCardSurfaceElevated
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricBlueLight
import com.example.ui.theme.FlameStreak
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent

val AnalyticsTimeframes = listOf("Weekly", "Monthly", "All-Time")

@Composable
fun AnalyticsScreen(
  userProfile: UserProfile?,
  habits: List<Habit>,
  tasks: List<TaskItem>,
  activityLogs: List<ActivityLog>
) {
  var selectedTimeframe by remember { mutableStateOf("Weekly") }

  val profile = userProfile ?: UserProfile()
  val past7Days = remember { GamificationEngine.getPastDays(7) }

  // Compute daily completions for the last 7 days from real habits
  val habitCompletionsPerDay = past7Days.map { day ->
    habits.count { it.isCompletedOn(day) }
  }

  // Compute XP per day from real activity logs
  val xpPerDay = past7Days.map { day ->
    activityLogs.filter { it.date == day }.sumOf { it.xpEarned }
  }

  val totalCompletedTasks = tasks.count { it.isCompleted }
  val totalPendingTasks = tasks.count { !it.isCompleted }
  val totalHabitsCount = habits.size
  val activeHabitsToday = habits.count { it.isCompletedOn(GamificationEngine.getTodayDateString()) }

  // Find most consistent habit
  val mostConsistentHabit = habits.maxByOrNull { it.bestStreak }

  // Category breakdown
  val categoryCounts = habits.groupBy { it.category }.mapValues { it.value.size }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Text(
        text = "Analytics & Telemetry",
        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
        color = TextPrimary,
        modifier = Modifier.padding(top = 8.dp)
      )
      Text(
        text = "Real-time metrics, XP velocity, and habit consistency charts.",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
      )

      Spacer(modifier = Modifier.height(14.dp))

      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(AnalyticsTimeframes) { tf ->
          val isSelected = tf == selectedTimeframe
          FilterChip(
            selected = isSelected,
            onClick = { selectedTimeframe = tf },
            label = { Text(tf) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = GoldPrimary,
              selectedLabelColor = Color(0xFF1E1700),
              containerColor = DarkCardSurface,
              labelColor = TextSecondary
            )
          )
        }
      }
    }

    item {
      // Metric Summary Cards Grid
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        AnalyticsMetricCard(
          title = "Total Earned XP",
          value = "${profile.totalXp} XP",
          subtitle = "Level ${profile.level}",
          accent = GoldPrimary,
          modifier = Modifier.weight(1f)
        )
        AnalyticsMetricCard(
          title = "Active Streak",
          value = "${profile.currentStreak} Days",
          subtitle = "Best: ${profile.bestStreak}d",
          accent = FlameStreak,
          modifier = Modifier.weight(1f)
        )
      }
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        AnalyticsMetricCard(
          title = "Habits Done Today",
          value = "$activeHabitsToday / $totalHabitsCount",
          subtitle = "Total: ${profile.completedHabitsCount}",
          accent = ElectricBlue,
          modifier = Modifier.weight(1f)
        )
        AnalyticsMetricCard(
          title = "Tasks Completed",
          value = "$totalCompletedTasks Done",
          subtitle = "$totalPendingTasks Pending",
          accent = SuccessGreen,
          modifier = Modifier.weight(1f)
        )
      }
    }

    item {
      // Weekly Habit Completion Velocity (Canvas Bar Chart)
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("weekly_completions_chart"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
        border = CardDefaults.outlinedCardBorder().copy(
          brush = Brush.linearGradient(listOf(DarkCardBorder, GoldPrimary.copy(alpha = 0.3f)))
        )
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.BarChart, contentDescription = null, tint = GoldLight)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Habit Consistency (Last 7 Days)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextPrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(18.dp))

          // Canvas Bar Chart
          WeeklyBarChart(
            days = past7Days,
            values = habitCompletionsPerDay
          )
        }
      }
    }

    item {
      // XP Inflow Trend (Canvas Smooth Line Chart)
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("xp_trend_chart"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
        border = CardDefaults.outlinedCardBorder().copy(
          brush = Brush.linearGradient(listOf(DarkCardBorder, ElectricBlue.copy(alpha = 0.3f)))
        )
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.AutoMirrored.Filled.ShowChart, contentDescription = null, tint = ElectricBlueLight)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "XP Inflow Velocity",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextPrimary
              )
            }
            Text(
              text = "+${xpPerDay.sum()} XP this week",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = GoldLight)
            )
          }

          Spacer(modifier = Modifier.height(18.dp))

          XpTrendLineChart(
            days = past7Days,
            xpValues = xpPerDay
          )
        }
      }
    }

    item {
      // Most Consistent Habit Spotlight
      if (mostConsistentHabit != null && mostConsistentHabit.bestStreak > 0) {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1405)),
          border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(listOf(GoldLight, GoldDark))
          )
        ) {
          Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.LocalFireDepartment,
              contentDescription = null,
              tint = FlameStreak,
              modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "Most Consistent Habit",
                style = MaterialTheme.typography.labelSmall.copy(color = GoldLight, fontWeight = FontWeight.Bold)
              )
              Text(
                text = mostConsistentHabit.name,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextPrimary
              )
              Text(
                text = "All-time record: ${mostConsistentHabit.bestStreak} day uninterrupted streak",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
              )
            }
          }
        }
      }
    }

    item {
      // Category Breakdown Card
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
        border = CardDefaults.outlinedCardBorder().copy(
          brush = Brush.linearGradient(listOf(DarkCardBorder, VioletAccent.copy(alpha = 0.3f)))
        )
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Category Distribution",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = TextPrimary
          )
          Spacer(modifier = Modifier.height(12.dp))
          if (categoryCounts.isEmpty()) {
            Text(text = "No habits to categorize yet.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
          } else {
            categoryCounts.forEach { (cat, count) ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(text = cat, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = GoldPrimary.copy(alpha = 0.15f)
                ) {
                  Text(
                    text = "$count Habit${if (count > 1) "s" else ""}",
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = GoldLight)
                  )
                }
              }
            }
          }
        }
      }
      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}

@Composable
private fun AnalyticsMetricCard(
  title: String,
  value: String,
  subtitle: String,
  accent: Color,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.linearGradient(listOf(DarkCardBorder, accent.copy(alpha = 0.3f)))
    )
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(text = title, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
      Spacer(modifier = Modifier.height(4.dp))
      Text(text = value, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
      Spacer(modifier = Modifier.height(2.dp))
      Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = accent)
    }
  }
}

@Composable
fun WeeklyBarChart(
  days: List<String>,
  values: List<Int>
) {
  val maxValue = (values.maxOrNull() ?: 1).coerceAtLeast(3)

  Column(modifier = Modifier.fillMaxWidth()) {
    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .height(130.dp)
    ) {
      val barWidth = 26.dp.toPx()
      val totalBars = days.size
      val spacing = (size.width - (barWidth * totalBars)) / (totalBars + 1)
      val corner = CornerRadius(8.dp.toPx(), 8.dp.toPx())

      for (i in 0 until totalBars) {
        val count = values.getOrElse(i) { 0 }
        val barHeight = ((count.toFloat() / maxValue.toFloat()) * size.height).coerceAtLeast(6f)
        val left = spacing + i * (barWidth + spacing)
        val top = size.height - barHeight

        // Background track bar
        drawRoundRect(
          color = Color(0xFF1E293B),
          topLeft = Offset(left, 0f),
          size = Size(barWidth, size.height),
          cornerRadius = corner
        )

        // Filled gradient bar
        drawRoundRect(
          brush = Brush.verticalGradient(
            listOf(GoldLight, GoldPrimary)
          ),
          topLeft = Offset(left, top),
          size = Size(barWidth, barHeight),
          cornerRadius = corner
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Day labels
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceAround
    ) {
      days.forEach { dayStr ->
        val shortLabel = if (dayStr.length >= 10) dayStr.substring(8, 10) else dayStr
        Text(
          text = shortLabel,
          style = MaterialTheme.typography.labelSmall,
          color = TextSecondary
        )
      }
    }
  }
}

@Composable
fun XpTrendLineChart(
  days: List<String>,
  xpValues: List<Int>
) {
  val maxXp = (xpValues.maxOrNull() ?: 100).coerceAtLeast(50)

  Column(modifier = Modifier.fillMaxWidth()) {
    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .height(110.dp)
    ) {
      val n = days.size
      if (n < 2) return@Canvas
      val stepX = size.width / (n - 1)

      val path = Path()
      val points = mutableListOf<Offset>()

      for (i in 0 until n) {
        val xp = xpValues.getOrElse(i) { 0 }
        val x = i * stepX
        val y = size.height - ((xp.toFloat() / maxXp.toFloat()) * (size.height - 20f)) - 10f
        points.add(Offset(x, y))
        if (i == 0) {
          path.moveTo(x, y)
        } else {
          path.lineTo(x, y)
        }
      }

      // Draw line
      drawPath(
        path = path,
        brush = Brush.horizontalGradient(listOf(ElectricBlue, VioletAccent)),
        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
      )

      // Draw point dots
      points.forEach { pt ->
        drawCircle(
          color = GoldLight,
          radius = 4.dp.toPx(),
          center = pt
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      days.forEach { dayStr ->
        val shortLabel = if (dayStr.length >= 10) dayStr.substring(5) else dayStr
        Text(
          text = shortLabel,
          style = MaterialTheme.typography.labelSmall,
          color = TextMuted
        )
      }
    }
  }
}
