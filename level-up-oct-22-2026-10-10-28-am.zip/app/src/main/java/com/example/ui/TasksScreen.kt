package com.example.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.GamificationEngine
import com.example.data.model.TaskItem
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkCardSurfaceElevated
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

val TaskFilterTabs = listOf("All", "Pending", "Completed", "High Priority")
val TaskPriorities = listOf("Low", "Medium", "High")

@Composable
fun TasksScreen(
  tasks: List<TaskItem>,
  selectedFilter: String,
  onSelectFilter: (String) -> Unit,
  onToggleTask: (TaskItem) -> Unit,
  onSaveTask: (id: String, title: String, desc: String, category: String, priority: String, dueDate: String, xp: Int) -> Unit,
  onDeleteTask: (String) -> Unit
) {
  var showCreateDialog by remember { mutableStateOf(false) }
  var taskToEdit by remember { mutableStateOf<TaskItem?>(null) }
  var taskToDelete by remember { mutableStateOf<TaskItem?>(null) }

  val filteredTasks = tasks.filter { task ->
    when (selectedFilter) {
      "Pending" -> !task.isCompleted
      "Completed" -> task.isCompleted
      "High Priority" -> task.priority.equals("High", ignoreCase = true)
      else -> true
    }
  }

  Box(modifier = Modifier.fillMaxSize()) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp)
    ) {
      Text(
        text = "Quests & Tasks",
        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
        color = TextPrimary,
        modifier = Modifier.padding(top = 8.dp)
      )
      Text(
        text = "Tackle actionable tasks, meet deadlines, and conquer your backlog.",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Filter Tabs
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(TaskFilterTabs) { tab ->
          val isSelected = tab == selectedFilter
          FilterChip(
            selected = isSelected,
            onClick = { onSelectFilter(tab) },
            label = {
              Text(
                text = tab,
                style = MaterialTheme.typography.labelMedium.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = GoldPrimary,
              selectedLabelColor = Color(0xFF1E1700),
              containerColor = DarkCardSurface,
              labelColor = TextSecondary
            ),
            border = FilterChipDefaults.filterChipBorder(
              enabled = true,
              selected = isSelected,
              borderColor = DarkCardBorder,
              selectedBorderColor = GoldLight
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      if (filteredTasks.isEmpty()) {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 24.dp),
          colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
          shape = RoundedCornerShape(16.dp),
          border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(DarkCardBorder, DarkCardBorder)))
        ) {
          Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = "No tasks found",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = TextPrimary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "Add a task below to conquer your daily objectives and gain XP.",
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary
            )
          }
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.fillMaxSize()
        ) {
          items(filteredTasks, key = { it.id }) { task ->
            TaskCard(
              task = task,
              onToggle = { onToggleTask(task) },
              onEdit = { taskToEdit = task },
              onDelete = { taskToDelete = task }
            )
          }
          item {
            Spacer(modifier = Modifier.height(80.dp))
          }
        }
      }
    }

    // FAB to Add Task
    FloatingActionButton(
      onClick = { showCreateDialog = true },
      containerColor = GoldPrimary,
      contentColor = Color(0xFF1E1700),
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(20.dp)
        .testTag("add_task_fab")
    ) {
      Icon(imageVector = Icons.Default.Add, contentDescription = "Add Task")
    }

    if (showCreateDialog || taskToEdit != null) {
      val task = taskToEdit
      TaskFormDialog(
        initialTask = task,
        onDismiss = {
          showCreateDialog = false
          taskToEdit = null
        },
        onSave = { title, desc, cat, priority, due, xp ->
          onSaveTask(task?.id ?: "", title, desc, cat, priority, due, xp)
          showCreateDialog = false
          taskToEdit = null
        }
      )
    }

    if (taskToDelete != null) {
      AlertDialog(
        onDismissRequest = { taskToDelete = null },
        title = { Text("Delete Task", color = TextPrimary) },
        text = { Text("Are you sure you want to delete '${taskToDelete?.title}'?", color = TextSecondary) },
        confirmButton = {
          Button(
            onClick = {
              taskToDelete?.id?.let { onDeleteTask(it) }
              taskToDelete = null
            },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
          ) {
            Text("Delete", color = Color.White)
          }
        },
        dismissButton = {
          TextButton(onClick = { taskToDelete = null }) {
            Text("Cancel", color = TextSecondary)
          }
        },
        containerColor = DarkCardSurfaceElevated
      )
    }
  }
}

@Composable
fun TaskCard(
  task: TaskItem,
  onToggle: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit
) {
  val priorityColor = when (task.priority.lowercase()) {
    "high" -> Color(0xFFEF4444)
    "medium" -> Color(0xFFF59E0B)
    else -> Color(0xFF10B981)
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("task_card_${task.id}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (task.isCompleted) DarkCardSurface.copy(alpha = 0.6f) else DarkCardSurface
    ),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.linearGradient(
        if (task.isCompleted) listOf(SuccessGreen.copy(alpha = 0.4f), DarkCardBorder)
        else listOf(DarkCardBorder, priorityColor.copy(alpha = 0.35f))
      )
    )
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
      ) {
        IconButton(
          onClick = onToggle,
          modifier = Modifier.size(28.dp).testTag("toggle_task_${task.id}")
        ) {
          Icon(
            imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (task.isCompleted) SuccessGreen else TextSecondary,
            modifier = Modifier.size(26.dp)
          )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = task.title,
            style = MaterialTheme.typography.bodyLarge.copy(
              fontWeight = FontWeight.SemiBold,
              color = if (task.isCompleted) TextSecondary else TextPrimary
            )
          )
          if (!task.description.isNullOrBlank()) {
            Text(
              text = task.description,
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary,
              maxLines = 2
            )
          }
        }

        Surface(
          shape = RoundedCornerShape(6.dp),
          color = GoldPrimary.copy(alpha = 0.15f)
        ) {
          Text(
            text = "+${task.xpReward} XP",
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = GoldLight)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth().padding(start = 38.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = priorityColor.copy(alpha = 0.2f)
          ) {
            Text(
              text = "${task.priority} Priority",
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = priorityColor)
            )
          }

          Spacer(modifier = Modifier.width(8.dp))

          Text(
            text = task.category,
            style = MaterialTheme.typography.labelSmall,
            color = GoldLight
          )

          if (task.dueDate != null) {
            Text(
              text = " • Due: ${task.dueDate}",
              style = MaterialTheme.typography.labelSmall,
              color = TextMuted
            )
          }
        }

        Row {
          IconButton(onClick = onEdit, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = TextSecondary, modifier = Modifier.size(14.dp))
          }
          IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444), modifier = Modifier.size(14.dp))
          }
        }
      }
    }
  }
}

@Composable
fun TaskFormDialog(
  initialTask: TaskItem?,
  onDismiss: () -> Unit,
  onSave: (title: String, desc: String, category: String, priority: String, due: String, xp: Int) -> Unit
) {
  var title by remember { mutableStateOf(initialTask?.title ?: "") }
  var description by remember { mutableStateOf(initialTask?.description ?: "") }
  var category by remember { mutableStateOf(initialTask?.category ?: "Productivity") }
  var priority by remember { mutableStateOf(initialTask?.priority ?: "Medium") }
  var dueDate by remember { mutableStateOf(initialTask?.dueDate ?: GamificationEngine.getTodayDateString()) }
  var xpReward by remember { mutableIntStateOf(initialTask?.xpReward ?: 35) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = if (initialTask == null) "Create New Task" else "Edit Task",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        color = TextPrimary
      )
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Task Title *") },
          placeholder = { Text("e.g. Implement Compose Navigation") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("task_title_input"),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GoldPrimary,
            unfocusedBorderColor = DarkCardBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          )
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("Description (Optional)") },
          modifier = Modifier.fillMaxWidth(),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GoldPrimary,
            unfocusedBorderColor = DarkCardBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          )
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(text = "Priority", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          TaskPriorities.forEach { p ->
            FilterChip(
              selected = priority == p,
              onClick = { priority = p },
              label = { Text(p) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = GoldPrimary,
                selectedLabelColor = Color(0xFF1E1700),
                containerColor = DarkCardSurface,
                labelColor = TextSecondary
              )
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = dueDate,
          onValueChange = { dueDate = it },
          label = { Text("Due Date (YYYY-MM-DD)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GoldPrimary,
            unfocusedBorderColor = DarkCardBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          )
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(text = "XP Reward: +$xpReward XP", style = MaterialTheme.typography.bodyMedium, color = GoldLight)
          Row {
            Button(
              onClick = { if (xpReward > 10) xpReward -= 5 },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.size(36.dp),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) { Text("-") }
            Spacer(modifier = Modifier.width(6.dp))
            Button(
              onClick = { if (xpReward < 250) xpReward += 5 },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.size(36.dp),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) { Text("+") }
          }
        }

        if (errorMessage != null) {
          Spacer(modifier = Modifier.height(6.dp))
          Text(text = errorMessage ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isBlank()) {
            errorMessage = "Task title cannot be blank"
          } else {
            onSave(title, description, category, priority, dueDate, xpReward)
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color(0xFF1E1700)),
        modifier = Modifier.testTag("save_task_button")
      ) {
        Text("Save Task", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel", color = TextSecondary)
      }
    },
    containerColor = DarkCardSurfaceElevated
  )
}
