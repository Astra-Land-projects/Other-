package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.Habit
import com.example.data.model.TaskItem
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class LevelUpRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun createHabit_validPayload_createsDocumentAndReturnsId() = runBlocking {
    signInTestUser(ALICE_EMAIL)
    val repository = LevelUpRepository(firestore, auth)

    val habit = Habit(
      name = "Daily Algorithms",
      category = "Study",
      xpReward = 40,
      targetDurationOrQuantity = "30 mins",
      frequency = "Daily"
    )

    val result = withTimeout(DEFAULT_TIMEOUT_MS) {
      repository.createHabit(habit)
    }

    assertTrue(result.isSuccess)
    val habitId = result.getOrThrow()
    assertNotNull(habitId)
  }

  @Test
  fun createTask_andObserve_emitsCreatedTask() = runBlocking {
    signInTestUser(ALICE_EMAIL)
    val repository = LevelUpRepository(firestore, auth)

    val title = "Task_${UUID.randomUUID()}"
    val task = TaskItem(
      title = title,
      category = "Programming",
      priority = "High",
      xpReward = 50
    )

    val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
      repository.createTask(task)
    }
    assertTrue(createResult.isSuccess)

    val tasks = withTimeout(FLOW_TIMEOUT_MS) {
      repository.observeTasks().first { list ->
        list.any { it.title == title }
      }
    }
    assertTrue(tasks.any { it.title == title })
  }

  @Test
  fun unauthenticatedUser_cannotAccessProtectedRepositoryMethods() = runBlocking {
    auth.signOut()
    val repository = LevelUpRepository(firestore, auth)

    val result = withTimeout(DEFAULT_TIMEOUT_MS) {
      repository.createHabit(Habit(name = "Illegal Habit"))
    }
    assertTrue(result.isFailure)
  }

  companion object {
    private const val ALICE_EMAIL = "alice_tester@test.com"
    private const val DEFAULT_TIMEOUT_MS = 6000L
    private const val FLOW_TIMEOUT_MS = 6000L
  }
}
